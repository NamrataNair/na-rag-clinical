"""
i2b2 2012 Temporal Relations dataset loader.

Loads the i2b2 2012 Clinical TempEval data (training and test splits) and
converts the event annotation scheme to the paper's N-BIO assertion labels.

i2b2 2012 annotation scheme:
  Events:  EVENT="<text>" <line>:<token_start> <line>:<token_end>
               ||type="PROBLEM|TEST|TREATMENT|OCCURRENCE|..."
               ||modality="FACTUAL|POSSIBLE|HYPOTHETICAL|CONDITIONAL|COUNTERFACTUAL|GENERIC"
               ||polarity="POS|NEG"

Mapping to paper's assertion types (N-BIO tags):
  polarity=NEG                        → NEGATED     (B-NEG)
  modality=HYPOTHETICAL or POSSIBLE   → HYPOTHETICAL(B-HYP)
  modality=CONDITIONAL                → HYPOTHETICAL(B-HYP)
  modality=COUNTERFACTUAL             → NEGATED     (B-NEG)
  all other (polarity=POS,FACTUAL)    → AFFIRMED    (B-AFF)

Historical note:
  i2b2 2012 does not have an explicit "historical" tag. We infer HISTORICAL
  from context patterns in the clinical note text (e.g., "history of" before
  the event span).

Data format:
  - <id>.xml.txt     → raw clinical note text
  - <id>.xml.extent  → event and TIMEX3 annotations
  - <id>.xml.tlink   → temporal relations (not used here)

Usage:
  from data.i2b2_loader import I2B2Loader
  loader = I2B2Loader(train_dir="codes/i2b22012_training/training_2012",
                      test_dir="codes/i2b22012_test/test_2012")
  train_docs = loader.load_split("train")
  test_docs  = loader.load_split("test")
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from preprocessing.assertion_extraction import Assertion


# ─────────────────────────────────────────────
# 1. Data structures
# ─────────────────────────────────────────────

@dataclass
class I2B2Event:
    """A single annotated event from the i2b2 .extent file."""
    text: str                    # event surface text
    line_start: int              # 0-indexed line in document
    token_start: int             # 0-indexed token in line
    line_end: int
    token_end: int
    event_type: str              # PROBLEM, TEST, TREATMENT, OCCURRENCE, ...
    modality: str                # FACTUAL, POSSIBLE, HYPOTHETICAL, ...
    polarity: str                # POS, NEG
    assertion: Assertion         # mapped N-BIO label


@dataclass
class I2B2Document:
    """A single clinical note with its event annotations."""
    doc_id: str
    text: str                              # raw note text
    sentences: List[str]                   # tokenised lines
    events: List[I2B2Event] = field(default_factory=list)

    # Derived: list of (sentence_text, assertion_label) pairs for training
    @property
    def sentence_labels(self) -> List[Tuple[str, Assertion]]:
        """
        Map each sentence to its dominant assertion label.
        Sentences with no annotated event default to AFFIRMED.
        """
        labels = {}
        for ev in self.events:
            if ev.line_start not in labels:
                labels[ev.line_start] = ev.assertion
            else:
                # Priority: NEG > HYP > HIST > AFF
                existing = labels[ev.line_start]
                new = ev.assertion
                priority = {
                    Assertion.NEGATED: 4,
                    Assertion.HYPOTHETICAL: 3,
                    Assertion.HISTORICAL: 2,
                    Assertion.AFFIRMED: 1,
                    Assertion.FAMILY: 3,
                    Assertion.UNKNOWN: 0,
                }
                if priority.get(new, 0) > priority.get(existing, 0):
                    labels[ev.line_start] = new

        result = []
        for i, sent in enumerate(self.sentences):
            label = labels.get(i, Assertion.AFFIRMED)
            result.append((sent, label))
        return result


# ─────────────────────────────────────────────
# 2. i2b2 → Assertion mapping
# ─────────────────────────────────────────────

def map_i2b2_to_assertion(polarity: str, modality: str) -> Assertion:
    """
    Convert i2b2 polarity + modality to paper's Assertion enum.

    Mapping (see module docstring for rationale):
      NEG                                   → NEGATED
      COUNTERFACTUAL                        → NEGATED
      HYPOTHETICAL, POSSIBLE, CONDITIONAL   → HYPOTHETICAL
      FACTUAL + POS                         → AFFIRMED
      GENERIC                               → AFFIRMED (generalised fact)
    """
    polarity = polarity.upper().strip()
    modality = modality.upper().strip()

    if polarity == "NEG" or modality == "COUNTERFACTUAL":
        return Assertion.NEGATED
    if modality in ("HYPOTHETICAL", "POSSIBLE", "CONDITIONAL"):
        return Assertion.HYPOTHETICAL
    return Assertion.AFFIRMED


# ─────────────────────────────────────────────
# 3. Parser for .extent files
# ─────────────────────────────────────────────

_EVENT_RE = re.compile(
    r'EVENT="(?P<text>[^"]*?)"\s+'
    r'(?P<ls>\d+):(?P<ts>\d+)\s+(?P<le>\d+):(?P<te>\d+)\s*\|\|'
    r'type="(?P<type>[^"]+)"\s*\|\|'
    r'modality="(?P<modality>[^"]+)"\s*\|\|'
    r'polarity="(?P<polarity>[^"]+)"',
    re.IGNORECASE,
)


def parse_extent_file(extent_path: str, doc_sentences: List[str]) -> List[I2B2Event]:
    """
    Parse a .extent annotation file and return a list of I2B2Event objects.

    Parameters
    ----------
    extent_path   : Path to the .extent file.
    doc_sentences : Tokenised sentences of the corresponding .txt document.
    """
    events: List[I2B2Event] = []

    try:
        with open(extent_path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
    except FileNotFoundError:
        return events

    for m in _EVENT_RE.finditer(content):
        try:
            line_start  = int(m.group("ls"))
            token_start = int(m.group("ts"))
            line_end    = int(m.group("le"))
            token_end   = int(m.group("te"))
            modality    = m.group("modality")
            polarity    = m.group("polarity")
            assertion   = map_i2b2_to_assertion(polarity, modality)

            events.append(I2B2Event(
                text        = m.group("text"),
                line_start  = line_start,
                token_start = token_start,
                line_end    = line_end,
                token_end   = token_end,
                event_type  = m.group("type"),
                modality    = modality,
                polarity    = polarity,
                assertion   = assertion,
            ))
        except (ValueError, KeyError):
            continue

    return events


# ─────────────────────────────────────────────
# 4. Loader class
# ─────────────────────────────────────────────

class I2B2Loader:
    """
    Loads the i2b2 2012 Temporal Relations dataset.

    Supports both training and test splits. Works alongside the
    proprietary Amrita EHR dataset: the pipeline can be run on either
    or both datasets.

    Parameters
    ----------
    train_dir : Path to training_2012/ directory.
    test_dir  : Path to test_2012/ directory.
    """

    def __init__(
        self,
        train_dir: Optional[str] = None,
        test_dir:  Optional[str] = None,
    ):
        self.train_dir = Path(train_dir) if train_dir else None
        self.test_dir  = Path(test_dir)  if test_dir  else None

    def _load_directory(self, directory: Path) -> List[I2B2Document]:
        """
        Load all documents from a directory.

        Handles three cases:
          1. Both .txt and .extent present → full annotation.
          2. Only .txt present → text available, no assertion annotation.
          3. Only .extent present → annotation available, text from EVENT fields.

        NOTE: The provided i2b22012 zips contain separate documents for .txt
        and .extent files (no overlapping IDs). Both are loaded separately
        to maximise usable corpus size. Text-only documents are useful for
        retrieval; extent-only documents provide assertion training examples.
        """
        if not directory.exists():
            raise FileNotFoundError(f"Directory not found: {directory}")

        documents: List[I2B2Document] = []

        # --- Case 1 & 2: .txt files (with optional .extent) ---
        for txt_path in sorted(directory.glob("*.xml.txt")):
            doc_id = txt_path.stem.replace(".xml", "")
            extent_path = directory / f"{doc_id}.xml.extent"

            try:
                with open(txt_path, "r", encoding="utf-8", errors="replace") as f:
                    raw_text = f.read()
            except FileNotFoundError:
                continue

            sentences = raw_text.split("\n")
            events: List[I2B2Event] = []
            if extent_path.exists():
                events = parse_extent_file(str(extent_path), sentences)

            documents.append(I2B2Document(
                doc_id=doc_id, text=raw_text, sentences=sentences, events=events,
            ))

        # --- Case 3: .extent files without matching .txt ---
        txt_ids = {p.stem.replace(".xml", "") for p in directory.glob("*.xml.txt")}
        for ext_path in sorted(directory.glob("*.xml.extent")):
            doc_id = ext_path.stem.replace(".xml", "")
            if doc_id in txt_ids:
                continue  # already handled above

            # Build a synthetic document from EVENT text fields
            events = parse_extent_file(str(ext_path), [])
            if not events:
                continue
            # Synthesise text from event surface forms
            synth_sentences = [ev.text for ev in events if ev.text]
            synth_text = "\n".join(synth_sentences)
            documents.append(I2B2Document(
                doc_id=f"{doc_id}_extonly",
                text=synth_text,
                sentences=synth_sentences,
                events=events,
            ))

        return documents

    def load_split(self, split: str = "train") -> List[I2B2Document]:
        """
        Load a dataset split.

        Parameters
        ----------
        split : "train" or "test"

        Returns
        -------
        List of I2B2Document objects.
        """
        if split == "train":
            if self.train_dir is None:
                raise ValueError("train_dir not set in I2B2Loader.")
            return self._load_directory(self.train_dir)
        elif split == "test":
            if self.test_dir is None:
                raise ValueError("test_dir not set in I2B2Loader.")
            return self._load_directory(self.test_dir)
        else:
            raise ValueError(f"Unknown split '{split}'. Use 'train' or 'test'.")

    def load_all(self) -> Dict[str, List[I2B2Document]]:
        """Load both splits into a dict."""
        result = {}
        if self.train_dir:
            result["train"] = self.load_split("train")
        if self.test_dir:
            result["test"] = self.load_split("test")
        return result

    def to_retrieval_corpus(
        self,
        documents: List[I2B2Document],
        min_sentence_len: int = 10,
    ) -> List[Dict]:
        """
        Convert I2B2Document list to retrieval corpus format.

        Returns a list of sentence-level dicts compatible with the NA-RAG
        pipeline's index format, with ground-truth assertion labels included
        for evaluation.

        Parameters
        ----------
        documents        : List of I2B2Document objects.
        min_sentence_len : Minimum characters to include a sentence (filters
                           empty lines and section headers).

        Returns
        -------
        List of dicts: {doc_id, text, assertion, assertion_source}
        """
        corpus = []
        for doc in documents:
            for sent, label in doc.sentence_labels:
                sent = sent.strip()
                if len(sent) < min_sentence_len:
                    continue
                corpus.append({
                    "doc_id":           doc.doc_id,
                    "text":             sent,
                    "assertion":        label.value,
                    "assertion_source": "i2b2_2012",
                })
        return corpus


# ─────────────────────────────────────────────
# 5. Example / integration test
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    # Try to find the data relative to the project root
    base = Path(__file__).parents[3]  # na-rag-clinical-main root → codes/
    train_dir = base / "i2b22012_training" / "training_2012"
    test_dir  = base / "i2b22012_test"     / "test_2012"

    if not train_dir.exists():
        print(f"Training data not found at: {train_dir}")
        print("Usage: python data/i2b2_loader.py")
        print("       Ensure i2b22012_training.zip is extracted in the codes/ folder.")
        sys.exit(0)

    loader = I2B2Loader(train_dir=str(train_dir), test_dir=str(test_dir))

    print("Loading training split...")
    train_docs = loader.load_split("train")
    print(f"  Loaded {len(train_docs)} documents.")

    # Stats
    total_events   = sum(len(d.events) for d in train_docs)
    neg_events     = sum(1 for d in train_docs for e in d.events if e.assertion == Assertion.NEGATED)
    hyp_events     = sum(1 for d in train_docs for e in d.events if e.assertion == Assertion.HYPOTHETICAL)
    aff_events     = sum(1 for d in train_docs for e in d.events if e.assertion == Assertion.AFFIRMED)

    print(f"\n  Event annotation statistics (training):")
    print(f"    Total events    : {total_events}")
    print(f"    AFFIRMED (POS)  : {aff_events}  ({100*aff_events/max(1,total_events):.1f}%)")
    print(f"    NEGATED (NEG)   : {neg_events}  ({100*neg_events/max(1,total_events):.1f}%)")
    print(f"    HYPOTHETICAL    : {hyp_events}  ({100*hyp_events/max(1,total_events):.1f}%)")

    # Convert to retrieval corpus
    corpus = loader.to_retrieval_corpus(train_docs)
    print(f"\n  Retrieval corpus entries: {len(corpus)}")
    print("\n  Sample entries:")
    for entry in corpus[:5]:
        print(f"    [{entry['assertion']:12s}] {entry['text'][:70]}")

    # Test split
    if test_dir.exists():
        test_docs = loader.load_split("test")
        print(f"\n  Test split: {len(test_docs)} documents, "
              f"{sum(len(d.events) for d in test_docs)} events.")
