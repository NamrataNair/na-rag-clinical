"""
Retrieval evaluation metrics (paper Sections 5–6).

Implements all metrics reported in the paper, including:
  - nDCG@k, Recall@k, MAP (standard IR metrics, Table 3)
  - Safety-Weighted DCG (S-nDCG@k) — penalises polarity mismatches
  - Negation FP rate — proportion of negated docs in top-k
  - Per-class metrics — separate reporting for AFFIRMED vs NEGATED queries
  - Bootstrap 95% CI + two-sample bootstrap p-value (reviewer Q3)
  - Assertion F1 per class

Reviewer clarifications addressed here:
  Q2: Per-class performance (negated vs affirmed queries) — see per_class_report()
  Q3: Bootstrap p-value for Neg FP rate difference — see bootstrap_pvalue()
  Q7: ICD/SOAP flag-mode explained in caller comments
  Clarity: "TF-IDF" (lexical fallback) vs "Dense" (neural) naming throughout
"""

from __future__ import annotations

import math
import random
from typing import Any, Dict, List, Optional, Set, Tuple


# ─────────────────────────────────────────────
# 1. Core retrieval metrics
# ─────────────────────────────────────────────

def dcg_at_k(results: List[Dict], k: int, rel_field: str = "relevance") -> float:
    """Discounted Cumulative Gain at k. relevance ∈ {0,1,2}."""
    return sum(
        float(r.get(rel_field, 0)) / math.log2(i + 2)
        for i, r in enumerate(results[:k])
    )

def ideal_dcg_at_k(results: List[Dict], k: int, rel_field: str = "relevance") -> float:
    """IDCG@k: sort by descending relevance first."""
    sorted_rels = sorted([float(r.get(rel_field, 0)) for r in results], reverse=True)
    return sum(rel / math.log2(i + 2) for i, rel in enumerate(sorted_rels[:k]))

def ndcg_at_k(results: List[Dict], k: int, rel_field: str = "relevance") -> float:
    """Normalised DCG@k ∈ [0,1]."""
    idcg = ideal_dcg_at_k(results, k, rel_field)
    return dcg_at_k(results, k, rel_field) / idcg if idcg > 0 else 0.0


# ─────────────────────────────────────────────
# 2. Safety-Weighted nDCG (S-nDCG)
# ─────────────────────────────────────────────

def safety_weighted_dcg(
    results: List[Dict],
    k: int,
    query_assertion: str = "affirmed",
    safety_penalty: float = 1.5,
    rel_field: str = "relevance",
) -> float:
    """
    Safety-Weighted DCG (S-DCG@k).

    Extends standard DCG with an additional penalty when a negated document is
    retrieved for an affirmed query (the primary clinical safety error).

    S-DCG@k = DCG@k  −  safety_penalty · Σ_{negated FPs in top-k} 1/log₂(rank+1)

    This directly captures the trade-off identified by the reviewer: standard
    nDCG does not penalise negation false positives, but S-nDCG does.

    Parameters
    ----------
    query_assertion : assertion type of the query ("affirmed", "negated", etc.)
    safety_penalty  : multiplier for FP penalty (default 1.5; tune empirically)
    """
    dcg = dcg_at_k(results, k, rel_field)
    penalty = 0.0
    if query_assertion == "affirmed":
        for i, r in enumerate(results[:k]):
            if r.get("assertion", "") == "negated":
                penalty += safety_penalty / math.log2(i + 2)
    elif query_assertion == "negated":
        for i, r in enumerate(results[:k]):
            if r.get("assertion", "") == "affirmed":
                penalty += safety_penalty / math.log2(i + 2)
    return max(0.0, dcg - penalty)

def safety_ndcg_at_k(
    results: List[Dict],
    k: int,
    query_assertion: str = "affirmed",
    safety_penalty: float = 1.5,
    rel_field: str = "relevance",
) -> float:
    """Normalised S-DCG@k ∈ [0,1] (normalised by standard IDCG)."""
    idcg = ideal_dcg_at_k(results, k, rel_field)
    s_dcg = safety_weighted_dcg(results, k, query_assertion, safety_penalty, rel_field)
    return s_dcg / idcg if idcg > 0 else 0.0


# ─────────────────────────────────────────────
# 3. Recall, Precision, MAP
# ─────────────────────────────────────────────

def recall_at_k(results, k, relevant_ids=None, id_field="doc_id",
                rel_field="relevance", min_rel=1.0) -> float:
    if relevant_ids is not None:
        total = len(relevant_ids)
        return sum(1 for r in results[:k] if r.get(id_field) in relevant_ids) / total if total else 0.0
    total = sum(1 for r in results if float(r.get(rel_field, 0)) >= min_rel)
    return sum(1 for r in results[:k] if float(r.get(rel_field, 0)) >= min_rel) / total if total else 0.0

def precision_at_k(results, k, relevant_ids=None, id_field="doc_id",
                   rel_field="relevance", min_rel=1.0) -> float:
    top_k = results[:k]
    if not top_k:
        return 0.0
    if relevant_ids is not None:
        return sum(1 for r in top_k if r.get(id_field) in relevant_ids) / k
    return sum(1 for r in top_k if float(r.get(rel_field, 0)) >= min_rel) / k

def average_precision(results, relevant_ids=None, id_field="doc_id",
                      rel_field="relevance", min_rel=1.0) -> float:
    if relevant_ids is not None:
        total = len(relevant_ids)
        if not total:
            return 0.0
        hits, ap_sum = 0, 0.0
        for i, r in enumerate(results):
            if r.get(id_field) in relevant_ids:
                hits += 1
                ap_sum += hits / (i + 1)
        return ap_sum / total
    total = sum(1 for r in results if float(r.get(rel_field, 0)) >= min_rel)
    if not total:
        return 0.0
    hits, ap_sum = 0, 0.0
    for i, r in enumerate(results):
        if float(r.get(rel_field, 0)) >= min_rel:
            hits += 1
            ap_sum += hits / (i + 1)
    return ap_sum / total


# ─────────────────────────────────────────────
# 4. Negation-specific metrics
# ─────────────────────────────────────────────

def negation_fp_rate(results: List[Dict]) -> float:
    """Proportion of retrieved results that are negated."""
    if not results:
        return 0.0
    return sum(1 for r in results if r.get("assertion") == "negated") / len(results)

def polarity_mismatch_rate(results: List[Dict], query_assertion: str, k: int) -> float:
    """
    Rate of polarity mismatches in top-k.
    For affirmed query: negated docs in top-k.
    For negated query:  affirmed docs in top-k.
    """
    top_k = results[:k]
    if not top_k:
        return 0.0
    if query_assertion == "affirmed":
        mismatches = sum(1 for r in top_k if r.get("assertion") == "negated")
    elif query_assertion == "negated":
        mismatches = sum(1 for r in top_k if r.get("assertion") == "affirmed")
    else:
        mismatches = sum(1 for r in top_k if r.get("assertion") != query_assertion)
    return mismatches / len(top_k)

def assertion_f1(predictions, gold_labels, target_class="negated"):
    """Precision, Recall, F1 for one assertion class."""
    tp = sum(1 for p, g in zip(predictions, gold_labels) if p == target_class and g == target_class)
    fp = sum(1 for p, g in zip(predictions, gold_labels) if p == target_class and g != target_class)
    fn = sum(1 for p, g in zip(predictions, gold_labels) if p != target_class and g == target_class)
    prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    rec  = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1   = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0.0
    return prec, rec, f1

def macro_f1(predictions, gold_labels):
    classes = set(gold_labels)
    return sum(assertion_f1(predictions, gold_labels, c)[2] for c in classes) / len(classes) if classes else 0.0


# ─────────────────────────────────────────────
# 5. Bootstrap CI and significance (reviewer Q3)
# ─────────────────────────────────────────────

def bootstrap_ci(scores: List[float], n_resamples: int = 1000,
                 alpha: float = 0.05, seed: int = 42) -> Tuple[float, float, float]:
    """
    95% nonparametric bootstrap CI for the mean of `scores`.
    Returns (mean, lower_bound, upper_bound).
    """
    rng = random.Random(seed)
    n = len(scores)
    if n == 0:
        return 0.0, 0.0, 0.0
    point = sum(scores) / n
    boot = sorted(sum(rng.choices(scores, k=n)) / n for _ in range(n_resamples))
    lo = boot[int(alpha / 2 * n_resamples)]
    hi = boot[int((1 - alpha / 2) * n_resamples) - 1]
    return point, lo, hi

def bootstrap_pvalue(scores_a: List[float], scores_b: List[float],
                     n_resamples: int = 1000, seed: int = 42) -> Tuple[float, float]:
    """
    Two-sample bootstrap significance test (one-tailed: is mean(B) < mean(A)?).
    Returns (observed_delta, p_value).

    Used for reviewer Q3: is the Neg FP rate reduction (full_model vs. −NBIO)
    statistically significant?

    H0: mean(A) - mean(B) ≤ 0
    Ha: mean(A) - mean(B) > 0  (A is higher — e.g., minus_nbio FP rate vs full_model)
    """
    if not scores_a or not scores_b:
        return 0.0, 1.0
    rng = random.Random(seed)
    obs_delta = sum(scores_a) / len(scores_a) - sum(scores_b) / len(scores_b)
    # Permutation under null
    combined = scores_a + scores_b
    na, nb = len(scores_a), len(scores_b)
    extreme = 0
    for _ in range(n_resamples):
        rng.shuffle(combined)
        delta_null = (sum(combined[:na]) / na - sum(combined[na:]) / nb)
        if delta_null >= obs_delta:
            extreme += 1
    p_val = extreme / n_resamples
    return obs_delta, p_val


# ─────────────────────────────────────────────
# 6. Per-class query analysis (reviewer Q2)
# ─────────────────────────────────────────────

def per_class_report(
    all_query_results: List[List[Dict]],
    query_assertions: List[str],
    k: int = 10,
    n_bootstrap: int = 1000,
) -> Dict[str, Dict]:
    """
    Compute retrieval metrics separately for each query assertion class.
    Returns dict: {assertion_class: {metric: value}}.

    Addresses reviewer Q2: per-query-class performance reporting.
    """
    classes = sorted(set(query_assertions))
    report = {}
    for cls in classes:
        idxs = [i for i, a in enumerate(query_assertions) if a == cls]
        if not idxs:
            continue
        cls_results = [all_query_results[i] for i in idxs]
        ndcg_scores = [ndcg_at_k(r, k) for r in cls_results]
        rec_scores  = [recall_at_k(r, k) for r in cls_results]
        ap_scores   = [average_precision(r) for r in cls_results]
        fp_scores   = [negation_fp_rate(r[:k]) for r in cls_results]
        s_ndcg_scores = [safety_ndcg_at_k(r, k, query_assertion=cls) for r in cls_results]
        pm_scores   = [polarity_mismatch_rate(r, cls, k) for r in cls_results]

        ndcg_m, ndcg_lo, ndcg_hi = bootstrap_ci(ndcg_scores, n_bootstrap)
        rec_m,  rec_lo,  rec_hi  = bootstrap_ci(rec_scores,  n_bootstrap)
        sndcg_m,_,_               = bootstrap_ci(s_ndcg_scores, n_bootstrap)
        report[cls] = {
            "n_queries":   len(idxs),
            "ndcg":        ndcg_m,
            "ndcg_ci":     (ndcg_lo, ndcg_hi),
            "recall":      rec_m,
            "recall_ci":   (rec_lo, rec_hi),
            "map":         sum(ap_scores) / len(ap_scores),
            "neg_fp_rate": sum(fp_scores) / len(fp_scores),
            "pm_rate":     sum(pm_scores) / len(pm_scores),   # polarity mismatch
            "s_ndcg":      sndcg_m,                            # safety-weighted nDCG
        }
    return report


# ─────────────────────────────────────────────
# 7. Multi-query aggregate evaluation
# ─────────────────────────────────────────────

def evaluate_retrieval_system(
    all_query_results: List[List[Dict]],
    all_relevant_ids: Optional[List[Set]] = None,
    k: int = 10,
    n_bootstrap: int = 1000,
    query_assertions: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Full retrieval evaluation matching Table 3 format.

    Returns means, 95% CIs, and (if query_assertions provided) per-class breakdown.
    """
    ndcg_scores   = [ndcg_at_k(r, k) for r in all_query_results]
    recall_scores = [recall_at_k(r, k) for r in all_query_results]
    ap_scores     = [average_precision(r) for r in all_query_results]
    neg_fp_rates  = [negation_fp_rate(r[:k]) for r in all_query_results]

    # Safety-nDCG (if query assertions provided)
    if query_assertions:
        s_ndcg = [safety_ndcg_at_k(r, k, qa)
                  for r, qa in zip(all_query_results, query_assertions)]
        pm_rates = [polarity_mismatch_rate(r, qa, k)
                    for r, qa in zip(all_query_results, query_assertions)]
    else:
        s_ndcg   = ndcg_scores
        pm_rates = neg_fp_rates

    ndcg_m,   ndcg_lo,   ndcg_hi   = bootstrap_ci(ndcg_scores,   n_bootstrap)
    recall_m, recall_lo, recall_hi = bootstrap_ci(recall_scores, n_bootstrap)
    map_m,    map_lo,    map_hi    = bootstrap_ci(ap_scores,      n_bootstrap)
    sn_m, _, _                     = bootstrap_ci(s_ndcg,         n_bootstrap)

    result = {
        "ndcg_at_k":   ndcg_m,    "ndcg_ci":   (ndcg_lo, ndcg_hi),
        "recall_at_k": recall_m,  "recall_ci": (recall_lo, recall_hi),
        "map":         map_m,     "map_ci":    (map_lo, map_hi),
        "neg_fp_rate": sum(neg_fp_rates) / len(neg_fp_rates) if neg_fp_rates else 0.0,
        "pm_rate":     sum(pm_rates) / len(pm_rates) if pm_rates else 0.0,
        "s_ndcg":      sn_m,
        "k":           k,
        "n_queries":   len(all_query_results),
    }

    if query_assertions:
        result["per_class"] = per_class_report(
            all_query_results, query_assertions, k, n_bootstrap
        )

    return result


# ─────────────────────────────────────────────
# 8. Significance test between two systems (reviewer Q3)
# ─────────────────────────────────────────────

def compare_systems(
    results_a: List[List[Dict]],
    results_b: List[List[Dict]],
    label_a: str = "System A",
    label_b: str = "System B",
    k: int = 10,
    n_bootstrap: int = 1000,
) -> Dict[str, Any]:
    """
    Compare two retrieval systems per query using bootstrap permutation test.

    Returns dict with per-metric (delta, p_value) for:
      - nDCG@k, Recall@k, MAP, Neg FP rate
    """
    fp_a = [negation_fp_rate(r[:k]) for r in results_a]
    fp_b = [negation_fp_rate(r[:k]) for r in results_b]
    ndcg_a = [ndcg_at_k(r, k) for r in results_a]
    ndcg_b = [ndcg_at_k(r, k) for r in results_b]
    recall_a = [recall_at_k(r, k) for r in results_a]
    recall_b = [recall_at_k(r, k) for r in results_b]

    fp_delta,    fp_p    = bootstrap_pvalue(fp_a,    fp_b,    n_bootstrap)
    ndcg_delta,  ndcg_p  = bootstrap_pvalue(ndcg_b,  ndcg_a,  n_bootstrap)  # B > A ?
    rec_delta,   rec_p   = bootstrap_pvalue(recall_b, recall_a, n_bootstrap)

    return {
        "label_a": label_a, "label_b": label_b,
        "neg_fp_delta": fp_delta,  "neg_fp_p": fp_p,
        "ndcg_delta":   ndcg_delta,"ndcg_p":   ndcg_p,
        "recall_delta": rec_delta, "recall_p": rec_p,
        "interpretation": (
            f"Neg FP: {label_a} has rate {sum(fp_a)/len(fp_a):.4f} vs "
            f"{label_b} {sum(fp_b)/len(fp_b):.4f} "
            f"(Δ={fp_delta:.4f}, p={fp_p:.3f})"
        ),
    }


if __name__ == "__main__":
    # Quick smoke test
    q1 = [{"doc_id":0,"relevance":2,"assertion":"affirmed"},
          {"doc_id":1,"relevance":0,"assertion":"negated"},
          {"doc_id":2,"relevance":1,"assertion":"historical"}]
    q2 = [{"doc_id":3,"relevance":2,"assertion":"negated"},
          {"doc_id":4,"relevance":1,"assertion":"hypothetical"},
          {"doc_id":5,"relevance":0,"assertion":"affirmed"}]
    print(f"nDCG@3={ndcg_at_k(q1,3):.4f}")
    print(f"S-nDCG@3(affirmed query)={safety_ndcg_at_k(q1,3,'affirmed'):.4f}")
    print(f"PM rate@3={polarity_mismatch_rate(q1,'affirmed',3):.4f}")
    m, lo, hi = bootstrap_ci([ndcg_at_k(q,3) for q in [q1,q2]])
    print(f"Bootstrap CI: {m:.4f} [{lo:.4f},{hi:.4f}]")
    print("All metrics: OK")
