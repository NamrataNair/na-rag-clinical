"""
Baseline experiment runner (paper Table 3 baselines).

Runs the following baselines against both the i2b2 2012 dataset
and (optionally) the Amrita proprietary EHR dataset:

  1. BM25 (lexical-only)
  2. Dense ClinicalBERT (cosine similarity only)
  3. Hybrid RRF (BM25 + Dense, no assertion)

The full NA-RAG pipeline (with NBIO, ICD, SOAP) is run in run_na_rag.py.

Results are printed in Table 3 format: nDCG@10, Recall@10, MAP with 95% CI.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

# Add project root to path
PROJECT_ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from data.i2b2_loader import I2B2Loader, I2B2Document
from evaluation.evaluate_retrieval import (
    evaluate_retrieval_system,
    ndcg_at_k,
    recall_at_k,
    average_precision,
)
from indexing.build_index import build_index
from indexing.bm25_index import build_bm25
from retrieval.dense_retriever import DenseRetriever
from utils.config import (
    EMBEDDING_MODEL,
    TOP_K,
    I2B2_TRAIN_DIR,
    I2B2_TEST_DIR,
    N_BOOTSTRAP,
    EVAL_K,
)


# ─────────────────────────────────────────────
# 1. BM25 baseline
# ─────────────────────────────────────────────

def run_bm25_baseline(
    corpus_texts: List[str],
    queries: List[str],
    relevant_ids_per_query: Optional[List[set]] = None,
    top_k: int = TOP_K,
) -> Dict[str, Any]:
    """
    BM25 lexical retrieval baseline.

    Parameters
    ----------
    corpus_texts         : List of document texts.
    queries              : List of query strings.
    relevant_ids_per_query: Ground-truth relevant doc indices per query.
    top_k                : Number of results to retrieve.

    Returns
    -------
    Dict with nDCG@k, Recall@k, MAP (means + 95% CI).
    """
    bm25 = build_bm25(corpus_texts)

    all_results = []
    for i, query in enumerate(queries):
        query_tokens = query.lower().split()
        scores = bm25.get_scores(query_tokens)

        # Rank by BM25 score
        ranked_indices = sorted(range(len(scores)), key=lambda j: scores[j], reverse=True)
        results = []
        for rank, idx in enumerate(ranked_indices[:top_k]):
            rel = 0
            if relevant_ids_per_query and i < len(relevant_ids_per_query):
                rel = 2 if idx in relevant_ids_per_query[i] else 0
            results.append({
                "doc_id":    idx,
                "text":      corpus_texts[idx],
                "score":     float(scores[idx]),
                "rank":      rank + 1,
                "relevance": rel,
            })
        all_results.append(results)

    report = evaluate_retrieval_system(
        all_results, relevant_ids_per_query, k=EVAL_K, n_bootstrap=N_BOOTSTRAP
    )
    report["model"] = "BM25 (lexical-only)"
    return report


# ─────────────────────────────────────────────
# 2. Dense baseline
# ─────────────────────────────────────────────

def run_dense_baseline(
    corpus_texts: List[str],
    queries: List[str],
    relevant_ids_per_query: Optional[List[set]] = None,
    top_k: int = TOP_K,
    model_name: str = EMBEDDING_MODEL,
) -> Dict[str, Any]:
    """
    Dense ClinicalBERT bi-encoder baseline (cosine similarity, no assertion).
    """
    retriever = DenseRetriever(model_name)
    corpus_embeddings = retriever.encode(corpus_texts)

    all_results = []
    for i, query in enumerate(queries):
        raw_results = retriever.retrieve(query, corpus_embeddings, corpus_texts, top_k=top_k)
        for r in raw_results:
            rel = 0
            if relevant_ids_per_query and i < len(relevant_ids_per_query):
                rel = 2 if r["doc_id"] in relevant_ids_per_query[i] else 0
            r["relevance"] = rel
        all_results.append(raw_results)

    report = evaluate_retrieval_system(
        all_results, relevant_ids_per_query, k=EVAL_K, n_bootstrap=N_BOOTSTRAP
    )
    report["model"] = f"Dense ({model_name})"
    return report


# ─────────────────────────────────────────────
# 3. Hybrid RRF baseline (BM25 + Dense, no assertion)
# ─────────────────────────────────────────────

def run_hybrid_rrf_baseline(
    corpus_texts: List[str],
    queries: List[str],
    relevant_ids_per_query: Optional[List[set]] = None,
    top_k: int = TOP_K,
    rrf_k: int = 60,
) -> Dict[str, Any]:
    """
    Hybrid Reciprocal Rank Fusion (BM25 + Dense) baseline.

    RRF score = 1/(k + rank_bm25) + 1/(k + rank_dense)

    Parameters
    ----------
    rrf_k : RRF constant (default 60, per Cormack et al. 2009).
    """
    retriever = DenseRetriever(EMBEDDING_MODEL)
    corpus_embeddings = retriever.encode(corpus_texts)
    bm25 = build_bm25(corpus_texts)

    all_results = []
    for i, query in enumerate(queries):
        # Dense ranking
        dense_res  = retriever.retrieve(query, corpus_embeddings, corpus_texts, top_k=top_k * 3)
        dense_rank = {r["doc_id"]: r["rank"] for r in dense_res}

        # BM25 ranking
        query_tokens = query.lower().split()
        bm25_scores  = bm25.get_scores(query_tokens)
        bm25_ranked  = sorted(range(len(bm25_scores)), key=lambda j: bm25_scores[j], reverse=True)
        bm25_rank    = {idx: rank + 1 for rank, idx in enumerate(bm25_ranked[: top_k * 3])}

        # RRF fusion over the union of candidate sets
        candidates = set(dense_rank.keys()) | set(bm25_rank.keys())
        rrf_scores = {}
        for doc_id in candidates:
            dr = dense_rank.get(doc_id, top_k * 3 + 1)
            br = bm25_rank.get(doc_id, top_k * 3 + 1)
            rrf_scores[doc_id] = 1.0 / (rrf_k + dr) + 1.0 / (rrf_k + br)

        ranked = sorted(rrf_scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
        results = []
        for rank, (doc_id, score) in enumerate(ranked):
            rel = 0
            if relevant_ids_per_query and i < len(relevant_ids_per_query):
                rel = 2 if doc_id in relevant_ids_per_query[i] else 0
            results.append({
                "doc_id":    doc_id,
                "text":      corpus_texts[doc_id],
                "score":     score,
                "rank":      rank + 1,
                "relevance": rel,
            })
        all_results.append(results)

    report = evaluate_retrieval_system(
        all_results, relevant_ids_per_query, k=EVAL_K, n_bootstrap=N_BOOTSTRAP
    )
    report["model"] = "Hybrid RRF (BM25+Dense)"
    return report


# ─────────────────────────────────────────────
# 4. Print Table 3 format
# ─────────────────────────────────────────────

def print_table3_row(report: Dict[str, Any]) -> None:
    """Print one row of Table 3."""
    ndcg_lo, ndcg_hi   = report.get("ndcg_ci",   (0, 0))
    rec_lo,  rec_hi    = report.get("recall_ci",  (0, 0))
    map_lo,  map_hi    = report.get("map_ci",     (0, 0))
    print(
        f"  {report.get('model', '?'):<35} "
        f"nDCG@{report.get('k',10)}={report['ndcg_at_k']:.3f} [{ndcg_lo:.3f},{ndcg_hi:.3f}]  "
        f"Recall@{report.get('k',10)}={report['recall_at_k']:.3f} [{rec_lo:.3f},{rec_hi:.3f}]  "
        f"MAP={report['map']:.3f} [{map_lo:.3f},{map_hi:.3f}]"
    )


# ─────────────────────────────────────────────
# 5. i2b2 demonstration run
# ─────────────────────────────────────────────

def run_baselines_on_i2b2() -> None:
    """
    Run all baselines on the i2b2 2012 dataset.

    Uses assertion-annotated events as a proxy for query–document relevance:
      - Query = first negated/hypothetical event text in a document
      - Relevant docs = other documents with the same assertion type
    This is a demonstration setup; final evaluation uses human-annotated
    query–note relevance pairs (paper Sec. 4).
    """
    print("Loading i2b2 2012 dataset...")

    # Try local paths relative to this file
    base_dir = Path(__file__).parents[3]  # codes/ directory
    train_dir = base_dir / "i2b22012_training" / "training_2012"
    test_dir  = base_dir / "i2b22012_test"     / "test_2012"

    if not train_dir.exists():
        print(f"  i2b2 training data not found at: {train_dir}")
        print("  Please extract i2b22012_training.zip in the codes/ folder.")
        return

    loader = I2B2Loader(str(train_dir), str(test_dir) if test_dir.exists() else None)
    docs   = loader.load_split("train")
    corpus_items = loader.to_retrieval_corpus(docs, min_sentence_len=20)

    if not corpus_items:
        print("  No corpus items loaded.")
        return

    corpus_texts = [c["text"] for c in corpus_items]
    print(f"  Corpus size: {len(corpus_texts)} sentences from {len(docs)} documents.")

    # Build simple demonstration queries (negated sentences as queries)
    neg_items = [c for c in corpus_items if c["assertion"] == "negated"][:20]
    if not neg_items:
        print("  No negated sentences found for demo queries.")
        return

    queries = [item["text"] for item in neg_items[:10]]

    # Simple relevance: a doc is relevant if it has the same assertion type
    # (approximate; replace with human annotations for final experiments)
    neg_indices = {i for i, c in enumerate(corpus_items) if c["assertion"] == "negated"}
    relevant_per_query = [neg_indices for _ in queries]

    print(f"\n  Demo queries: {len(queries)}, corpus: {len(corpus_texts)} sentences")
    print(f"  Relevant docs per query (same assertion type): {len(neg_indices)}")
    print("\n  Running baselines...")
    print("=" * 100)
    print(f"  {'Model':<35} nDCG@10  [95% CI]                Recall@10  [95% CI]          MAP [95% CI]")
    print("-" * 100)

    bm25_report   = run_bm25_baseline(corpus_texts, queries, relevant_per_query)
    print_table3_row(bm25_report)

    dense_report  = run_dense_baseline(corpus_texts, queries, relevant_per_query)
    print_table3_row(dense_report)

    hybrid_report = run_hybrid_rrf_baseline(corpus_texts, queries, relevant_per_query)
    print_table3_row(hybrid_report)

    print("=" * 100)
    print("\n  NOTE: These are demonstration results with proxy relevance labels.")
    print("  Final results require human-annotated query–note relevance pairs (paper Sec. 4).")
    print("  Replace relevant_per_query with actual relevance annotations before reporting.")


def run_baseline():
    """Entry point: run all baselines."""
    run_baselines_on_i2b2()


if __name__ == "__main__":
    run_baseline()
