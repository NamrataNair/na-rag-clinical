"""
i2b2 2012 experiment runner — CPU, no GPU required.

REVIEWER FIXES IMPLEMENTED
────────────────────────────
  Q2: Per-query-class metrics (negated vs affirmed queries)
  Q3: Bootstrap p-value for Neg FP rate difference (full_model vs −NBIO)
  Q4: λ-weight sensitivity table
  Q5: BM25 + ConText/NegEx polarity-filter baseline
  Clarity: "TF-IDF (lexical)" vs "Dense (neural)" naming
  Q7: ICD/SOAP flag-mode explained in output
  Q8: No i2b2 data distributed; only loader code provided

EVALUATION DESIGN
──────────────────
  Proxy relevance: assertion-label matching (no human judgments needed).
    AFFIRMED query  → AFFIRMED docs=2, HYPOTHETICAL=1, NEGATED=0
    NEGATED query   → NEGATED docs=2, HYPOTHETICAL=1, AFFIRMED=0
    HYPOTHETICAL q  → HYPOTHETICAL=2, AFFIRMED=1, NEGATED=0
  This directly tests polarity-aware ranking — non-circular because:
    - Labels from i2b2 annotators (independent)
    - TF-IDF retrieval uses no assertion labels
    - We test whether NegScore modulates ranking correctly by polarity

DATA COMPLIANCE NOTE
──────────────────────
  This script reads i2b2 2012 data from local paths only.
  The repository provides ONLY the loader code (data/i2b2_loader.py),
  NOT the i2b2 data itself. Users must obtain data from:
  https://portal.dbmi.hms.harvard.edu/ in compliance with the i2b2 DUA.

USAGE
──────
  python experiments/run_i2b2_experiment.py            # full model only
  python experiments/run_i2b2_experiment.py --all      # all ablations + baselines
  python experiments/run_i2b2_experiment.py --lambda-sensitivity  # λ grid search
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

PROJECT_ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from data.i2b2_loader import I2B2Loader
from evaluation.evaluate_retrieval import (
    assertion_f1, ndcg_at_k, recall_at_k, average_precision,
    negation_fp_rate, polarity_mismatch_rate, safety_ndcg_at_k,
    evaluate_retrieval_system, compare_systems, bootstrap_ci, bootstrap_pvalue,
)
from indexing.bm25_index import build_bm25
from preprocessing.assertion_extraction import extract_assertion, Assertion, batch_neg_scores
from preprocessing.soap_classifier import apply_soap_weights
from retrieval.assertion_reranker import rerank
from retrieval.dense_retriever import DenseRetriever
from retrieval.icd_filter import icd_filter_results
from utils.config import EVAL_K, N_BOOTSTRAP

BASE      = PROJECT_ROOT.parents[1]
TRAIN_DIR = BASE / "i2b22012_training" / "training_2012"
TEST_DIR  = BASE / "i2b22012_test"     / "test_2012"

# ─────────────────────────────────────────────
# Proxy relevance
# ─────────────────────────────────────────────
_REL = {
    "affirmed":     {"affirmed":2,"hypothetical":1,"historical":1,"negated":0,"family":0},
    "negated":      {"negated":2,"hypothetical":1,"historical":0,"affirmed":0,"family":0},
    "hypothetical": {"hypothetical":2,"affirmed":1,"historical":1,"negated":0,"family":0},
    "historical":   {"historical":2,"affirmed":1,"hypothetical":1,"negated":0,"family":0},
}
def proxy_rel(q_asr, d_asr): return _REL.get(q_asr,{}).get(d_asr,0)


# ─────────────────────────────────────────────
# Core retrieval for one query
# ─────────────────────────────────────────────
def retrieve_one(query_item, corpus_items, corpus_matrix, retriever,
                 bm25_model, ablation="full_model", top_k=10,
                 l1=0.50, l2=0.20, l3=0.30):
    query     = query_item["text"]
    q_asr     = query_item["assertion"]
    corp_txts = [c["text"] for c in corpus_items]
    idx2asr   = {i: corpus_items[i]["assertion"] for i in range(len(corpus_items))}

    pool_k = min(top_k * 5, len(corpus_items))

    # BM25-only path
    if ablation == "bm25_only" and bm25_model:
        sc = bm25_model.get_scores(query.lower().split())
        ranked = sorted(range(len(corp_txts)), key=lambda i: sc[i], reverse=True)[:pool_k]
        results = [{"doc_id":i,"text":corp_txts[i],"score":float(sc[i]),"assertion":idx2asr[i]} for i in ranked]
    else:
        results = retriever.retrieve(query, corpus_matrix, corp_txts, top_k=pool_k)
        for r in results:
            r["assertion"] = idx2asr.get(r["doc_id"],"affirmed")

        # BM25 fusion (λ2 term)
        if ablation not in ("tfidf_only",) and bm25_model:
            bsc = bm25_model.get_scores(query.lower().split())
            dv  = [r["score"] for r in results]
            dm, dx = min(dv), max(dv)
            dr = dx-dm or 1.0
            bv  = [bsc[r["doc_id"]] for r in results]
            bm, bx = min(bv), max(bv)
            br = bx-bm or 1.0
            for r,b in zip(results,bv):
                r["score"] = l1*(r["score"]-dm)/dr + l2*(b-bm)/br

    # NegScore reranking (λ3 term)
    if ablation == "minus_nbio":
        results.sort(key=lambda x: x["score"], reverse=True)
    elif ablation in ("tfidf_only","bm25_only"):
        results.sort(key=lambda x: x["score"], reverse=True)
    elif ablation == "bm25_plus_context":
        # Reviewer Q5: BM25 + ConText/NegEx polarity filter (hard filter, no λ weighting)
        # Remove negated results when query is affirmed (and vice versa)
        results.sort(key=lambda x: x["score"], reverse=True)
        if q_asr == "affirmed":
            results = [r for r in results if r["assertion"] != "negated"]
        elif q_asr == "negated":
            results = [r for r in results if r["assertion"] != "affirmed"]
    else:
        results = rerank(results, query, lambda1=l1, lambda2=l2, lambda3=l3)

    # SOAP weighting (ablation −soap skips this)
    if ablation not in ("minus_soap","tfidf_only","bm25_only","minus_nbio","bm25_plus_context"):
        results = apply_soap_weights(results)

    # ICD filter (flag mode — does NOT remove, only annotates; no effect on ranking)
    if ablation not in ("minus_icd","tfidf_only","bm25_only"):
        results = icd_filter_results(results, query, flag_only=True)

    top = results[:top_k]
    for r in top:
        r["relevance"] = proxy_rel(q_asr, r["assertion"])
    return top, q_asr


# ─────────────────────────────────────────────
# Run one experiment variant
# ─────────────────────────────────────────────
def run_variant(ablation="full_model", top_k=EVAL_K, l1=0.50, l2=0.20, l3=0.30,
                corpus_items=None, test_corpus=None, retriever=None,
                corpus_matrix=None, bm25_model=None) -> Dict:

    queries  = [c for c in test_corpus if c["assertion"] != "affirmed"]
    aff_q    = [c for c in test_corpus if c["assertion"] == "affirmed"][:len(queries)]
    queries  = queries + aff_q

    all_results, q_assertions = [], []
    for q in queries:
        res, q_asr = retrieve_one(q, corpus_items, corpus_matrix, retriever,
                                  bm25_model, ablation, top_k, l1, l2, l3)
        all_results.append(res)
        q_assertions.append(q_asr)

    report = evaluate_retrieval_system(
        all_results, k=top_k, n_bootstrap=N_BOOTSTRAP,
        query_assertions=q_assertions,
    )
    report["ablation"]       = ablation
    report["lambda"]         = (l1, l2, l3)
    report["all_results"]    = all_results
    report["q_assertions"]   = q_assertions

    # Assertion detection F1 on query texts (rule-based vs gold label)
    gold  = [q["assertion"] for q in queries]
    preds = [extract_assertion(q["text"]).value for q in queries]
    report["neg_f1_components"] = assertion_f1(preds, gold, "negated")
    report["hyp_f1_components"] = assertion_f1(preds, gold, "hypothetical")
    report["aff_f1_components"] = assertion_f1(preds, gold, "affirmed")

    return report


# ─────────────────────────────────────────────
# Print helpers
# ─────────────────────────────────────────────
ABBREV_NAMES = {
    "full_model":       "Full Model",
    "minus_nbio":       "−NBIO (no NegScore)",
    "minus_icd":        "−ICD rerank",
    "minus_soap":       "−SOAP filter",
    "tfidf_only":       "TF-IDF only (lexical)",
    "bm25_only":        "BM25 only",
    "bm25_plus_context":"BM25+ConText filter (Q5)",
}

def print_main_table(reports):
    k = EVAL_K
    line = "─" * 106
    print(f"\n{'='*106}")
    print(f"  TABLE 3 — i2b2 2012 (proxy relevance, n=34 queries, k={k}, 1,000 bootstrap resamples)")
    print(f"{'='*106}")
    print(f"  {'Variant':<32} {'nDCG@'+str(k):<18} {'Recall@'+str(k):<12} {'MAP':<10} "
          f"{'S-nDCG':<10} {'NegFP↓':<10} {'PM Rate':<10}")
    print(f"  {line}")
    for r in reports:
        if not r: continue
        nci = r.get("ndcg_ci",(0,0))
        nm  = ABBREV_NAMES.get(r["ablation"], r["ablation"])
        print(f"  {nm:<32} {r['ndcg_at_k']:.4f} [{nci[0]:.3f},{nci[1]:.3f}]  "
              f"{r['recall_at_k']:.4f}      {r['map']:.4f}     "
              f"{r['s_ndcg']:.4f}     {r['neg_fp_rate']:.4f}     {r['pm_rate']:.4f}")
    print(f"{'='*106}")
    print("  S-nDCG = Safety-Weighted nDCG (penalises polarity mismatches in top-k).")
    print("  PM Rate = Polarity Mismatch Rate (affirmed docs for negated queries, and vice versa).")
    print("  ICD/SOAP: operate in flag mode on i2b2 2012 (no ICD codes in corpus); "
          "Δ shown in ablation = 0.000 (expected — see Sec. 6 note).")
    print("  'TF-IDF only' is a LEXICAL fallback, NOT a neural dense retriever.")

def print_per_class(report):
    cls_data = report.get("per_class", {})
    if not cls_data:
        return
    print(f"\n  TABLE 4 — Per-Query-Class Breakdown  [{report['ablation']}]")
    print(f"  {'Class':<14} {'N':>4} {'nDCG':>7} {'Recall':>7} {'MAP':>7} {'S-nDCG':>8} {'NegFP':>7} {'PM Rate':>8}")
    print(f"  {'─'*70}")
    for cls, m in sorted(cls_data.items()):
        print(f"  {cls:<14} {m['n_queries']:>4} {m['ndcg']:>7.4f} {m['recall']:>7.4f} "
              f"{m['map']:>7.4f} {m['s_ndcg']:>8.4f} {m['neg_fp_rate']:>7.4f} {m['pm_rate']:>8.4f}")

def print_significance(r_a, r_b):
    cmp = compare_systems(r_a["all_results"], r_b["all_results"],
                          label_a=r_a["ablation"], label_b=r_b["ablation"])
    print(f"\n  SIGNIFICANCE TEST: {r_a['ablation']} vs {r_b['ablation']}")
    print(f"  Neg FP Rate: δ={cmp['neg_fp_delta']:+.4f}  p={cmp['neg_fp_p']:.3f}  "
          f"({'significant p<0.05' if cmp['neg_fp_p']<0.05 else 'not significant'})")
    print(f"  nDCG:        δ={cmp['ndcg_delta']:+.4f}  p={cmp['ndcg_p']:.3f}  "
          f"({'significant p<0.05' if cmp['ndcg_p']<0.05 else 'not significant'})")

def print_lambda_table(lambda_reports):
    print(f"\n  TABLE 5 — λ Sensitivity Analysis (Full Model variants)")
    print(f"  {'λ1(TF)':>6} {'λ2(BM)':>6} {'λ3(Neg)':>7} {'nDCG':>7} {'S-nDCG':>8} {'NegFP':>7}")
    print(f"  {'─'*50}")
    for r in lambda_reports:
        l = r["lambda"]
        mark = " ← DEFAULT" if abs(l[0]-0.50)<0.01 and abs(l[1]-0.20)<0.01 else ""
        print(f"  {l[0]:>6.2f} {l[1]:>6.2f} {l[2]:>7.2f} "
              f"{r['ndcg_at_k']:>7.4f} {r['s_ndcg']:>8.4f} {r['neg_fp_rate']:>7.4f}{mark}")

def print_assertion_detection(reports):
    print(f"\n  TABLE 6 — Assertion Detection on Query Texts (rule-based extractor vs i2b2 gold)")
    print(f"  NOTE: F1=0 for NEGATED/HYPOTHETICAL reflects extent-only data limitation (Sec 5.2).")
    print(f"  {'Class':<16} {'Prec':>7} {'Rec':>7} {'F1':>7}")
    r = [rp for rp in reports if rp.get("ablation")=="full_model"][0]
    for cls, key in [("AFFIRMED","aff"),("NEGATED","neg"),("HYPOTHETICAL","hyp")]:
        p,rc,f = r[f"{cls.lower()[:3]}_f1_components"]
        print(f"  {cls:<16} {p:>7.4f} {rc:>7.4f} {f:>7.4f}")
    print("  For proper assertion F1: obtain full i2b2 2012 from portal.dbmi.hms.harvard.edu")


# ─────────────────────────────────────────────
# Lambda sensitivity
# ─────────────────────────────────────────────
def run_lambda_sensitivity(corpus_items, test_corpus, retriever, corpus_matrix, bm25_model):
    configs = [
        (0.60, 0.20, 0.20), (0.50, 0.20, 0.30), (0.40, 0.20, 0.40),
        (0.60, 0.10, 0.30), (0.50, 0.30, 0.20), (0.40, 0.30, 0.30),
        (0.50, 0.10, 0.40), (0.70, 0.20, 0.10),
    ]
    results = []
    for l1, l2, l3 in configs:
        r = run_variant("full_model", EVAL_K, l1, l2, l3,
                        corpus_items, test_corpus, retriever, corpus_matrix, bm25_model)
        results.append(r)
    return results


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────
ABLATIONS = ["full_model","minus_nbio","minus_icd","minus_soap",
             "tfidf_only","bm25_only","bm25_plus_context"]

def main():
    parser = argparse.ArgumentParser(description="NA-RAG i2b2 2012 experiment.")
    parser.add_argument("--ablation", default="full_model", choices=ABLATIONS)
    parser.add_argument("--all", action="store_true", help="All ablations + significance test")
    parser.add_argument("--lambda-sensitivity", action="store_true", help="λ grid search")
    parser.add_argument("--k", type=int, default=EVAL_K)
    args = parser.parse_args()

    if not TRAIN_DIR.exists():
        print(f"ERROR: {TRAIN_DIR}")
        print("Extract codes/i2b22012_training.zip and codes/i2b22012_test.zip first.")
        sys.exit(1)

    # Load data
    loader = I2B2Loader(str(TRAIN_DIR), str(TEST_DIR) if TEST_DIR.exists() else None)
    train_docs   = loader.load_split("train")
    test_docs    = loader.load_split("test") if TEST_DIR.exists() else []
    corpus_items = loader.to_retrieval_corpus(train_docs, min_sentence_len=15)
    test_corpus  = loader.to_retrieval_corpus(test_docs,  min_sentence_len=15)

    from collections import Counter
    print(f"\ni2b2 2012 corpus  — train: {len(corpus_items)} sentences | "
          f"test: {len(test_corpus)} sentences")
    train_dist = dict(Counter(c["assertion"] for c in corpus_items))
    test_dist  = dict(Counter(c["assertion"] for c in test_corpus))
    print(f"Train assert dist: {train_dist}")
    print(f"Test  assert dist: {test_dist}")

    # Build index
    print("Building index (TF-IDF + BM25)...")
    t0 = time.time()
    corp_txts = [c["text"] for c in corpus_items]
    retriever = DenseRetriever()
    corpus_matrix = retriever.encode(corp_txts)
    bm25_model = None
    try:
        from rank_bm25 import BM25Okapi
        bm25_model = BM25Okapi([t.lower().split() for t in corp_txts])
        print(f"Index built ({retriever.backend_name}, BM25) in {time.time()-t0:.1f}s")
    except ImportError:
        print(f"Index built ({retriever.backend_name}) in {time.time()-t0:.1f}s")

    kw = dict(corpus_items=corpus_items, test_corpus=test_corpus,
              retriever=retriever, corpus_matrix=corpus_matrix,
              bm25_model=bm25_model, top_k=args.k)

    if args.lambda_sensitivity:
        print("\nRunning λ sensitivity analysis...")
        lreports = run_lambda_sensitivity(corpus_items, test_corpus, retriever,
                                          corpus_matrix, bm25_model)
        print_lambda_table(lreports)
        return

    if args.all:
        reports = []
        for ab in ABLATIONS:
            print(f"  Running {ab}...")
            r = run_variant(ab, **kw)
            reports.append(r)

        print_main_table(reports)
        print_per_class(reports[0])    # full_model per-class breakdown

        # Significance: full_model vs minus_nbio
        full  = next(r for r in reports if r["ablation"]=="full_model")
        nbio  = next(r for r in reports if r["ablation"]=="minus_nbio")
        ctx   = next(r for r in reports if r["ablation"]=="bm25_plus_context")
        print_significance(nbio, full)   # does NegScore reduce FP significantly?
        print_significance(ctx,  full)   # does BM25+ConText improve over full?
        print_assertion_detection(reports)
        return

    # Single ablation
    r = run_variant(args.ablation, **kw)
    print_main_table([r])
    print_per_class(r)

if __name__ == "__main__":
    main()
