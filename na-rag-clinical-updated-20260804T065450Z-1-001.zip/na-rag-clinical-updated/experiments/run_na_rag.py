"""
Full NA-RAG pipeline runner (paper Sec. 3 / Table 3 / Table 7).

Runs the complete assertion-aware hybrid retrieval pipeline:
  1. Build assertion-annotated index (N-BIO tags)
  2. Dense + BM25 hybrid retrieval
  3. Assertion-aware re-ranking (NegScore, Eq. 1)
  4. ICD-grounded filtering (Eq. 3)
  5. SOAP-aware weighting (ablation −SOAP)
  6. Prompt generation + guardrails
  7. Evaluation (nDCG@10, Recall@10, MAP)

Runs on:
  - i2b2 2012 dataset (public benchmark)
  - Amrita proprietary EHR (when available; see config.py)

Ablation variants (Table 7) can be selected via --ablation flag.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

PROJECT_ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from data.i2b2_loader import I2B2Loader
from evaluation.evaluate_retrieval import evaluate_retrieval_system, negation_fp_rate
from generation.generation_guardrails import check_faithfulness
from generation.prompt_templates import build_prompt
from indexing.build_index import build_index
from preprocessing.assertion_extraction import extract_assertion
from preprocessing.soap_classifier import apply_soap_weights
from retrieval.assertion_reranker import (
    rerank,
    rerank_dense_only,
    rerank_no_nbio,
    rerank_lexical_only,
)
from retrieval.dense_retriever import DenseRetriever, HybridRetriever
from retrieval.icd_filter import icd_filter_results
from utils.config import (
    ABLATION_VARIANTS,
    EMBEDDING_MODEL,
    EVAL_K,
    I2B2_TRAIN_DIR,
    I2B2_TEST_DIR,
    ICD_FLAG_ONLY,
    ICD_THRESHOLD,
    LAMBDA1_DENSE,
    LAMBDA2_LEXICAL,
    LAMBDA3_NEG_SCORE,
    N_BOOTSTRAP,
    SOAP_FILTER_ENABLED,
    TOP_K,
    AblationConfig,
)


# ─────────────────────────────────────────────
# 1. Core NA-RAG pipeline function
# ─────────────────────────────────────────────

def run_na_rag_pipeline(
    query: str,
    corpus_texts: List[str],
    corpus_embeddings,
    index: List[Dict],
    retriever: DenseRetriever,
    ablation: Optional[AblationConfig] = None,
    top_k: int = TOP_K,
) -> Dict[str, Any]:
    """
    Run the full NA-RAG pipeline for a single query.

    Parameters
    ----------
    query             : Clinical query string.
    corpus_texts      : Corpus sentence texts.
    corpus_embeddings : Pre-encoded corpus embeddings.
    index             : Assertion-annotated index (from build_index()).
    retriever         : DenseRetriever instance.
    ablation          : Optional AblationConfig (for Table 7 variants).
    top_k             : Number of results to retrieve.

    Returns
    -------
    Dict with keys: query, results, prompt, is_faithful, neg_fp_rate.
    """
    if ablation is None:
        ablation = AblationConfig(name="full_model")

    # Step 1: Retrieve initial results (Dense or Hybrid)
    if ablation.lexical_only:
        # BM25-only (no dense)
        from indexing.bm25_index import build_bm25
        bm25 = build_bm25(corpus_texts)
        bm25_scores = bm25.get_scores(query.lower().split())
        ranked = sorted(range(len(bm25_scores)), key=lambda i: bm25_scores[i], reverse=True)[:top_k * 2]
        results = [
            {"doc_id": idx, "text": corpus_texts[idx], "score": float(bm25_scores[idx]),
             "assertion": index[idx]["assertion"] if idx < len(index) else "affirmed"}
            for idx in ranked
        ]
    else:
        results = retriever.retrieve(query, corpus_embeddings, corpus_texts, top_k=top_k * 2)
        # Map assertion from index
        text_to_assertion = {entry["text"]: entry["assertion"] for entry in index}
        for r in results:
            r["assertion"] = text_to_assertion.get(r["text"], "affirmed")

    # Step 2: Assertion-aware re-ranking (NegScore, Eq. 1)
    if ablation.dense_only:
        results = rerank_dense_only(results, query)
    elif ablation.lambda3 == 0.0:
        results = rerank_no_nbio(results, query)
    else:
        results = rerank(
            results, query,
            lambda1=ablation.lambda1,
            lambda2=ablation.lambda2,
            lambda3=ablation.lambda3,
        )

    # Step 3: ICD-grounded filtering (Eq. 3)
    if ablation.icd_filter:
        results = icd_filter_results(
            results, query,
            threshold=ICD_THRESHOLD,
            flag_only=ICD_FLAG_ONLY,
        )

    # Step 4: SOAP-aware weighting
    if ablation.soap_filter and SOAP_FILTER_ENABLED:
        results = apply_soap_weights(results)

    # Take top-k after all reranking
    top_results = results[:top_k]

    # Step 5: Prompt generation
    prompt = build_prompt(query, top_results)

    # Step 6: Guardrails check (simulated with prompt as generated text)
    is_faithful = check_faithfulness(prompt, top_results)
    neg_fp = negation_fp_rate(top_results)

    return {
        "query":        query,
        "results":      top_results,
        "prompt":       prompt,
        "is_faithful":  is_faithful,
        "neg_fp_rate":  neg_fp,
        "ablation":     ablation.name,
    }


# ─────────────────────────────────────────────
# 2. Backward-compat wrapper
# ─────────────────────────────────────────────

def run_na_rag(results: List[Dict], query: Optional[str] = None) -> List[Dict]:
    """
    Minimal backward-compatible wrapper.
    Accepts pre-retrieved results and applies assertion re-ranking only.
    """
    return rerank(results, query)


# ─────────────────────────────────────────────
# 3. i2b2 experiment runner
# ─────────────────────────────────────────────

def run_na_rag_on_i2b2(ablation_name: str = "full_model") -> None:
    """Run NA-RAG pipeline on the i2b2 2012 dataset."""
    print(f"Running NA-RAG [{ablation_name}] on i2b2 2012...")

    base_dir  = Path(__file__).parents[3]
    train_dir = base_dir / "i2b22012_training" / "training_2012"

    if not train_dir.exists():
        print(f"  i2b2 data not found: {train_dir}")
        print("  Please extract i2b22012_training.zip.")
        return

    # Find ablation config
    ablation = next((ab for ab in ABLATION_VARIANTS if ab.name == ablation_name), None)
    if ablation is None:
        print(f"  Unknown ablation '{ablation_name}'. Using full_model.")
        ablation = ABLATION_VARIANTS[0]

    # Load data
    loader = I2B2Loader(str(train_dir))
    docs   = loader.load_split("train")
    corpus_items = loader.to_retrieval_corpus(docs, min_sentence_len=20)
    corpus_texts = [c["text"] for c in corpus_items]
    print(f"  Corpus: {len(corpus_texts)} sentences from {len(docs)} documents.")

    # Build index
    documents = [[c["text"]] for c in corpus_items]
    index = build_index(documents)

    # Set up retriever
    retriever = DenseRetriever(EMBEDDING_MODEL)
    print("  Encoding corpus...")
    corpus_embeddings = retriever.encode(corpus_texts)

    # Use negated sentences as demo queries
    neg_items = [c for c in corpus_items if c["assertion"] == "negated"][:10]
    if not neg_items:
        print("  No negated examples found for demo queries.")
        return

    queries = [item["text"] for item in neg_items]
    print(f"  Running {len(queries)} demo queries...")

    all_results_for_eval = []
    for query in queries:
        output = run_na_rag_pipeline(
            query, corpus_texts, corpus_embeddings, index, retriever, ablation
        )
        all_results_for_eval.append(output["results"])

    # Evaluate (proxy: negated docs as relevant)
    neg_indices = {i for i, c in enumerate(corpus_items) if c["assertion"] == "negated"}
    rel_per_q = [neg_indices for _ in queries]

    # Annotate results with relevance
    for res_list in all_results_for_eval:
        for r in res_list:
            r["relevance"] = 2 if r.get("doc_id") in neg_indices else 0

    report = evaluate_retrieval_system(all_results_for_eval, rel_per_q, k=EVAL_K)
    ndcg_lo, ndcg_hi = report["ndcg_ci"]
    rec_lo, rec_hi   = report["recall_ci"]
    map_lo, map_hi   = report["map_ci"]

    print(f"\n  Results [{ablation.name}] on i2b2 2012 (demo):")
    print(f"    nDCG@{EVAL_K}   : {report['ndcg_at_k']:.3f} [{ndcg_lo:.3f}, {ndcg_hi:.3f}]")
    print(f"    Recall@{EVAL_K} : {report['recall_at_k']:.3f} [{rec_lo:.3f}, {rec_hi:.3f}]")
    print(f"    MAP        : {report['map']:.3f} [{map_lo:.3f}, {map_hi:.3f}]")
    print(f"    Neg FP rate: {report['neg_fp_rate']:.3f}")
    print("\n  NOTE: Proxy relevance used. Replace with human annotations for final results.")


# ─────────────────────────────────────────────
# 4. Entry point
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Run NA-RAG pipeline on i2b2 2012.")
    parser.add_argument(
        "--ablation",
        type=str,
        default="full_model",
        choices=[ab.name for ab in ABLATION_VARIANTS],
        help="Ablation variant to run (default: full_model).",
    )
    parser.add_argument(
        "--all-ablations",
        action="store_true",
        help="Run all ablation variants and print Table 7.",
    )
    args = parser.parse_args()

    if args.all_ablations:
        print("Running all ablation variants (Table 7)...")
        for ab in ABLATION_VARIANTS:
            run_na_rag_on_i2b2(ab.name)
            print()
    else:
        run_na_rag_on_i2b2(args.ablation)
