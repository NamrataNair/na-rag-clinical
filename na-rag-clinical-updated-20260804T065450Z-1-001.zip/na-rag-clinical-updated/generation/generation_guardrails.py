"""
Post-generation assertion consistency guardrails (paper Sec. 3.2).

Checks that generated clinical text does not:
  1. Assert conditions that were explicitly negated in the evidence
  2. Claim current conditions that are only historical in the evidence
  3. Present hypothetical findings as confirmed diagnoses

Key improvement over prior version
------------------------------------
The old check_faithfulness() used verbatim substring matching, which fails
when the generation paraphrases the negated finding. The new implementation:
  - Uses key-term extraction to identify the medical concept, then checks
    whether the generated text asserts it without a negation marker.
  - Adds a safety rate metric (violations per 100 outputs) aligned to
    the paper's safety evaluation (Sec. 8, Table 3).

NOTE: Full semantic faithfulness checking (e.g., with NLI or LLM judge)
is a planned extension. This rule-based check provides a deterministic
lower bound for safety auditing.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple


# ─────────────────────────────────────────────
# 1. Negation cues for output text
# ─────────────────────────────────────────────

_OUTPUT_NEGATION_CUES = [
    "no evidence of", "denies", "negative for", "not present",
    "absent", "without", "not seen", "ruled out", "no history of",
    "not", "no ", "cannot be confirmed",
]


def _text_contains_negation(text: str, concept: str) -> bool:
    """
    Check whether generated text negates a medical concept.
    Returns True if a negation cue precedes the concept within 30 chars.
    """
    text_lower = text.lower()
    concept_lower = concept.lower()

    # Find all positions of the concept
    for m in re.finditer(re.escape(concept_lower), text_lower):
        start = m.start()
        # Check the 30 characters before the concept for negation cues
        context_before = text_lower[max(0, start - 40): start]
        for cue in _OUTPUT_NEGATION_CUES:
            if cue in context_before:
                return True
    return False


def _extract_key_terms(text: str, max_terms: int = 5) -> List[str]:
    """
    Extract key medical terms from a sentence.
    Simple heuristic: noun phrases of 1-3 words (≥4 chars each).
    Replace with NER for production use.
    """
    words = re.findall(r'\b[A-Za-z]{4,}\b', text)
    # Exclude common function words
    stopwords = {
        "the", "this", "that", "with", "from", "have", "been",
        "were", "will", "patient", "evidence", "finding", "shown",
        "noted", "history", "present", "current", "also",
    }
    terms = [w.lower() for w in words if w.lower() not in stopwords]
    return list(dict.fromkeys(terms))[:max_terms]  # deduplicate, preserve order


# ─────────────────────────────────────────────
# 2. Core faithfulness check
# ─────────────────────────────────────────────

def check_faithfulness(
    generated_text: str,
    evidence: List[Dict[str, Any]],
    check_historical: bool = True,
    check_hypothetical: bool = False,
) -> bool:
    """
    Check that generated clinical text is faithful to the evidence.

    Returns True if faithful (no violations), False if a violation is detected.

    Violation types checked:
      1. NEGATED finding asserted as positive (always checked)
      2. HISTORICAL finding claimed as current (if check_historical=True)
      3. HYPOTHETICAL finding stated as confirmed (if check_hypothetical=True)

    Parameters
    ----------
    generated_text    : Text produced by the LLM generator.
    evidence          : Retrieved evidence dicts with "text" and "assertion".
    check_historical  : Also flag if historical conditions are wrongly asserted
                        as current. Default True.
    check_hypothetical: Also flag if hypothetical findings are stated as
                        confirmed. Default False (less strict, reduces FP).

    Returns
    -------
    bool — True if faithful (no violation), False if a violation is found.
    """
    gen_lower = generated_text.lower()

    for ev in evidence:
        assertion = ev.get("assertion", "affirmed")
        ev_text   = ev.get("text", "")
        key_terms = _extract_key_terms(ev_text)

        if assertion == "negated":
            # Check if generated text asserts any key term from a negated finding
            for term in key_terms:
                if term in gen_lower and not _text_contains_negation(generated_text, term):
                    return False

        elif assertion == "historical" and check_historical:
            # Check if generated text uses present tense for a historical condition
            for term in key_terms:
                if term in gen_lower:
                    # Red flags: "has", "is", "presents with" without "history of"
                    context_re = re.search(
                        rf'\b(has|is experiencing|presents with|currently has)\b.{{0,50}}{re.escape(term)}',
                        gen_lower,
                    )
                    if context_re:
                        return False

        elif assertion == "hypothetical" and check_hypothetical:
            for term in key_terms:
                if term in gen_lower:
                    # Red flag: stating as confirmed without uncertainty markers
                    if not re.search(
                        rf'\b(possible|suspected|may have|might have|could be|probable)\b.{{0,50}}{re.escape(term)}',
                        gen_lower,
                    ):
                        return False

    return True


# ─────────────────────────────────────────────
# 3. Safety rate metric (paper Sec. 8)
# ─────────────────────────────────────────────

def compute_safety_rate(
    generated_texts: List[str],
    evidence_sets: List[List[Dict[str, Any]]],
) -> Dict[str, float]:
    """
    Compute safety metrics over a batch of generated outputs.

    Returns a dict with:
      - violation_rate : proportion of outputs with ≥1 faithfulness violation
      - violations_per_100 : violations per 100 generated recommendations
      - safe_rate : 1 − violation_rate
    """
    if not generated_texts:
        return {"violation_rate": 0.0, "violations_per_100": 0.0, "safe_rate": 1.0}

    n = len(generated_texts)
    violations = 0
    for gen_text, evidence in zip(generated_texts, evidence_sets):
        if not check_faithfulness(gen_text, evidence):
            violations += 1

    violation_rate = violations / n
    return {
        "violation_rate":     violation_rate,
        "violations_per_100": violation_rate * 100,
        "safe_rate":          1.0 - violation_rate,
        "n_outputs":          n,
        "n_violations":       violations,
    }


# ─────────────────────────────────────────────
# 4. Example
# ─────────────────────────────────────────────

if __name__ == "__main__":
    evidence = [
        {"text": "CT scan showed no evidence of appendicitis.", "assertion": "negated"},
        {"text": "He has a history of diabetes.",               "assertion": "historical"},
        {"text": "The patient is experiencing chest pain.",     "assertion": "affirmed"},
        {"text": "Possible pneumonia cannot be excluded.",      "assertion": "hypothetical"},
    ]

    test_outputs = [
        ("The patient has appendicitis.",
         "VIOLATION expected: asserts negated condition"),
        ("No evidence of appendicitis. Patient has chest pain.",
         "OK: faithfully negates appendicitis"),
        ("The patient currently has diabetes.",
         "VIOLATION expected: presents historical condition as current"),
        ("The patient has a history of diabetes.",
         "OK: correctly uses historical framing"),
        ("Pneumonia confirmed.",
         "Possible VIOLATION: asserts hypothetical as confirmed (strict check)"),
    ]

    print("Faithfulness check results:")
    for gen_text, description in test_outputs:
        result = check_faithfulness(gen_text, evidence, check_historical=True)
        print(f"  {'✓ FAITHFUL' if result else '✗ VIOLATION'}  [{description}]")
        print(f"    Generated: \"{gen_text}\"")

    print("\nSafety rate over batch:")
    texts    = [t for t, _ in test_outputs]
    ev_sets  = [evidence] * len(texts)
    metrics  = compute_safety_rate(texts, ev_sets)
    for k, v in metrics.items():
        print(f"  {k}: {v}")
