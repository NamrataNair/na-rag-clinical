"""
Assertion extraction for clinical text.

Implements N-BIO tagging for negation, temporality, and certainty,
mirroring the paper's N-BIO module (Sec. 3.2, Eq. 2).

Tag scheme (paper-aligned):
  B-AFF / I-AFF   — affirmed  (current, positive finding)
  B-NEG / I-NEG   — negated   ("no evidence of", "denies")
  B-HIST / I-HIST — historical ("history of", "prior episode")
  B-HYP / I-HYP   — hypothetical ("possible", "suspected")
  B-FAM / I-FAM   — family history ("mother had", "family history of")

NegScore (Eq. 1 in paper):
  Measures polarity/temporality alignment between a document span
  and the query's requested assertion state.
  Range: [-1, +1]
    +1  => perfect polarity match (e.g. query=AFF, span=AFF)
     0  => neutral / unknown
    -1  => polarity mismatch (e.g. query=AFF, span=NEG)

NOTE on roadmap:
  The current implementation is rule-based (NegEx/ConText-style) for
  reproducibility and transparency. The paper's full N-BIO module
  (transformer encoder + CRF + triplet contrastive loss, Eq. 2) requires
  annotated training data and is the next implementation milestone.
  The interface (extract_assertion, extract_assertion_spans, compute_neg_score)
  is designed so the rule-based backend can be swapped for an ML model
  without changing downstream callers.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional


# ─────────────────────────────────────────────
# 1. Assertion taxonomy  (paper-aligned N-BIO tags)
# ─────────────────────────────────────────────

class Assertion(Enum):
    AFFIRMED     = "affirmed"      # B-AFF / I-AFF
    NEGATED      = "negated"       # B-NEG / I-NEG
    HISTORICAL   = "historical"    # B-HIST / I-HIST
    HYPOTHETICAL = "hypothetical"  # B-HYP / I-HYP
    FAMILY       = "family"        # B-FAM / I-FAM
    UNKNOWN      = "unknown"       # fallback when no cue detected


# Backward-compat alias (old code used ASSERTED)
Assertion.ASSERTED = Assertion.AFFIRMED   # type: ignore[attr-defined]


# ─────────────────────────────────────────────
# 2. NegScore polarity matrix  (Eq. 1 implementation)
# ─────────────────────────────────────────────

# _POLARITY_MATRIX[doc_assertion][query_short] = NegScore in [-1, +1]
# Rows  = document assertion type
# Cols  = query assertion type (short code)
#
# Interpretation:
#   +1.0 = perfect polarity/temporality alignment
#    0.0 = orthogonal (e.g. family history vs. current finding)
#   -1.0 = direct polarity clash (doc says "no X", query asks for "X")
_POLARITY_MATRIX: Dict[Assertion, Dict[str, float]] = {
    Assertion.AFFIRMED: {
        "AFF":  1.0,  "NEG": -1.0, "HIST": -0.5,
        "HYP":  0.3,  "FAM":  0.0, "UNK":  0.5,
    },
    Assertion.NEGATED: {
        "AFF": -1.0,  "NEG":  1.0, "HIST":  0.0,
        "HYP": -0.3,  "FAM":  0.0, "UNK": -0.5,
    },
    Assertion.HISTORICAL: {
        "AFF": -0.5,  "NEG":  0.0, "HIST":  1.0,
        "HYP":  0.2,  "FAM":  0.3, "UNK":  0.2,
    },
    Assertion.HYPOTHETICAL: {
        "AFF":  0.3,  "NEG": -0.3, "HIST":  0.2,
        "HYP":  1.0,  "FAM":  0.0, "UNK":  0.3,
    },
    Assertion.FAMILY: {
        "AFF":  0.0,  "NEG":  0.0, "HIST":  0.3,
        "HYP":  0.0,  "FAM":  1.0, "UNK":  0.0,
    },
    Assertion.UNKNOWN: {
        "AFF":  0.5,  "NEG": -0.5, "HIST":  0.2,
        "HYP":  0.3,  "FAM":  0.0, "UNK":  0.0,
    },
}

_SHORT: Dict[Assertion, str] = {
    Assertion.AFFIRMED:     "AFF",
    Assertion.NEGATED:      "NEG",
    Assertion.HISTORICAL:   "HIST",
    Assertion.HYPOTHETICAL: "HYP",
    Assertion.FAMILY:       "FAM",
    Assertion.UNKNOWN:      "UNK",
}


# ─────────────────────────────────────────────
# 3. Cue dictionaries  (NegEx / ConText inspired)
# ─────────────────────────────────────────────

NEGATION_CUES: List[str] = [
    "no evidence of", "no sign of", "without evidence of", "free of",
    "denies", "denied", "negative for", "not present", "absent",
    "no history of", "rule out", "ruled out", "ruled-out",
    "not seen", "not noted", "cannot be confirmed", "no known",
    "no active", "no acute", "without", "never had",
]

HISTORICAL_CUES: List[str] = [
    "history of", "h/o", "prior to", "previously",
    "past medical history", "past history", "remote history",
    "had a history", "known history", "chronic history",
    "remote episode of", "prior", "previous",
]

HYPOTHETICAL_CUES: List[str] = [
    "possible", "possibly", "probable", "probably", "suspected",
    "cannot exclude", "cannot rule out", "concern for",
    "may have", "might have", "could be", "suggestive of",
    "consider", "question of",
]

FAMILY_CUES: List[str] = [
    "family history of", "family history", "fh:", "fhx:",
    "mother had", "father had", "sister had", "brother had",
    "parent had", "grandparent had", "grandmother had", "grandfather had",
    "sibling had", "daughter had", "son had", "aunt had", "uncle had",
    "familial", "hereditary",
]


def _compile(cues: List[str]) -> re.Pattern:
    """Sort longest-first (prevents prefix shadowing), add word boundaries."""
    sorted_cues = sorted(cues, key=len, reverse=True)
    pattern = r"\b(" + "|".join(re.escape(c) for c in sorted_cues) + r")\b"
    return re.compile(pattern, re.IGNORECASE)


NEGATION_REGEX    = _compile(NEGATION_CUES)
HISTORICAL_REGEX  = _compile(HISTORICAL_CUES)
HYPOTHETICAL_REGEX = _compile(HYPOTHETICAL_CUES)
FAMILY_REGEX      = _compile(FAMILY_CUES)

# Legacy aliases for backward compatibility
NEGATION_PATTERNS    = NEGATION_CUES
HYPOTHETICAL_PATTERNS = HYPOTHETICAL_CUES
HISTORICAL_PATTERNS  = HISTORICAL_CUES
FAMILY_PATTERNS      = FAMILY_CUES


# ─────────────────────────────────────────────
# 4. Span-level data structure
# ─────────────────────────────────────────────

@dataclass
class AssertionSpan:
    """A single detected assertion cue span within a sentence."""
    text: str
    start_char: int
    end_char: int
    assertion: Assertion
    bio_tag: str       # e.g. "B-NEG", "B-HIST", "B-AFF"
    confidence: float  # 1.0 for rule-based; extend with ML probability


# ─────────────────────────────────────────────
# 5. Sentence-level classification
# ─────────────────────────────────────────────

def extract_assertion(sentence: str) -> Assertion:
    """
    Classify the dominant assertion polarity of a sentence.

    Priority order (clinical-safety motivated):
      FAMILY > NEGATED > HYPOTHETICAL > HISTORICAL > AFFIRMED

    This order ensures family history and negations are never silently
    upgraded to affirmed current findings—the most dangerous retrieval
    error in clinical decision support.

    Returns
    -------
    Assertion enum value for the sentence.
    """
    s = sentence.lower().strip()

    if FAMILY_REGEX.search(s):
        return Assertion.FAMILY
    if NEGATION_REGEX.search(s):
        return Assertion.NEGATED
    if HYPOTHETICAL_REGEX.search(s):
        return Assertion.HYPOTHETICAL
    if HISTORICAL_REGEX.search(s):
        return Assertion.HISTORICAL
    return Assertion.AFFIRMED


# ─────────────────────────────────────────────
# 6. Span-level extraction (N-BIO tagging)
# ─────────────────────────────────────────────

def extract_assertion_spans(sentence: str) -> List[AssertionSpan]:
    """
    Extract all assertion cue spans from a sentence with N-BIO tags.

    Handles MIXED polarity within a single sentence (e.g., "No evidence of
    appendicitis but history of cholecystitis" → [B-NEG, B-HIST]).

    NOTE: Full token-level B/I tagging (as in the paper's transformer+CRF
    N-BIO module, Eq. 2) is a planned extension. Current implementation
    marks the cue phrase itself as B-tag and leaves I-tagging for future
    work.

    Returns
    -------
    List[AssertionSpan] sorted by start_char.
    """
    s = sentence.lower()
    spans: List[AssertionSpan] = []

    # Priority: FAM > NEG > HYP > HIST (same as sentence-level)
    regex_map = [
        (FAMILY_REGEX,       Assertion.FAMILY,       "B-FAM"),
        (NEGATION_REGEX,     Assertion.NEGATED,       "B-NEG"),
        (HYPOTHETICAL_REGEX, Assertion.HYPOTHETICAL,  "B-HYP"),
        (HISTORICAL_REGEX,   Assertion.HISTORICAL,    "B-HIST"),
    ]

    covered: set = set()  # char positions already tagged (no overlap)
    for regex, assertion, bio_tag in regex_map:
        for m in regex.finditer(s):
            start, end = m.start(), m.end()
            if any(p in covered for p in range(start, end)):
                continue
            covered.update(range(start, end))
            spans.append(AssertionSpan(
                text=sentence[start:end],
                start_char=start,
                end_char=end,
                assertion=assertion,
                bio_tag=bio_tag,
                confidence=1.0,
            ))

    if not spans:
        # No cue found → treat whole sentence as affirmed
        spans.append(AssertionSpan(
            text=sentence,
            start_char=0,
            end_char=len(sentence),
            assertion=Assertion.AFFIRMED,
            bio_tag="B-AFF",
            confidence=0.9,  # Lower confidence: absence of cue ≠ positive evidence
        ))

    return sorted(spans, key=lambda sp: sp.start_char)


# ─────────────────────────────────────────────
# 7. NegScore — paper Eq. 1 alignment term
# ─────────────────────────────────────────────

def compute_neg_score(
    doc_sentence: str,
    query_sentence: str,
    doc_assertion: Optional[Assertion] = None,
    query_assertion: Optional[Assertion] = None,
) -> float:
    """
    Compute NegScore(d_i, q) as defined in the paper's Eq. 1.

    NegScore measures polarity/temporality alignment between a retrieved
    document sentence d_i and the query q.  It is the λ3 term in:

        R_MM(q) = argmax_{d_i ∈ D} [
            λ1 · cos(q, d_i^dense)
          + λ2 · Jaccard(q, d_i^meta)
          + λ3 · NegScore(d_i, q)
        ]

    Semantics:
        +1.0  ⟹ exact polarity/temporality match
         0.0  ⟹ orthogonal assertions
        -1.0  ⟹ direct polarity clash

    Mixed-polarity documents: we use the dominant (first-priority)
    assertion as the representative label—consistent with the single-label
    retrieval scoring use case.  For multi-span documents, use the span
    most relevant to the query concept (extend by concept matching).

    Parameters
    ----------
    doc_sentence :   Raw text of the candidate document sentence.
    query_sentence : Raw text of the query.
    doc_assertion :  Pre-computed Assertion for doc (computed if None).
    query_assertion: Pre-computed Assertion for query (computed if None).

    Returns
    -------
    float in [-1.0, +1.0]
    """
    if doc_assertion is None:
        doc_assertion = extract_assertion(doc_sentence)
    if query_assertion is None:
        query_assertion = extract_assertion(query_sentence)

    q_short = _SHORT[query_assertion]
    return _POLARITY_MATRIX[doc_assertion][q_short]


def batch_neg_scores(
    doc_sentences: List[str],
    query_sentence: str,
) -> List[float]:
    """
    Compute NegScore for a list of document sentences against one query.
    Efficient: query assertion is computed once.
    """
    query_assertion = extract_assertion(query_sentence)
    q_short = _SHORT[query_assertion]
    return [
        _POLARITY_MATRIX[extract_assertion(d)][q_short]
        for d in doc_sentences
    ]


# ─────────────────────────────────────────────
# 8. Example / smoke test
# ─────────────────────────────────────────────

if __name__ == "__main__":
    test_cases = [
        ("The patient has diabetes.",               "Does the patient have diabetes?"),
        ("No evidence of appendicitis was found.",  "Does the patient have appendicitis?"),
        ("History of hypertension.",                "Does the patient have hypertension?"),
        ("Possible pneumonia cannot be ruled out.", "Does the patient have pneumonia?"),
        ("Family history of coronary artery disease.", "Any family history of heart disease?"),
        ("CT scan showed no evidence of appendicitis.", "ruled out appendicitis"),
    ]

    print(f"{'Document sentence':<55} {'Doc':<14} {'Query':<14} {'NegScore':>8}")
    print("-" * 100)
    for doc, query in test_cases:
        da  = extract_assertion(doc)
        qa  = extract_assertion(query)
        ns  = compute_neg_score(doc, query, da, qa)
        print(f"{doc[:54]:<55} {da.value:<14} {qa.value:<14} {ns:>8.2f}")

    print("\nSpan extraction example:")
    text = ("CT scan showed no evidence of appendicitis but "
            "patient has history of cholecystitis.")
    for sp in extract_assertion_spans(text):
        print(f"  [{sp.bio_tag}] '{sp.text}' → {sp.assertion.value} (conf={sp.confidence:.2f})")
