"""
SOAP section classifier (paper Sec. 4 / Sec. 8, ablation −SOAP).

Classifies sentences/passages from clinical notes into SOAP sections:
  S — Subjective  (patient-reported symptoms, history)
  O — Objective   (vitals, exam findings, lab results)
  A — Assessment  (diagnosis, clinical impression)
  P — Plan        (treatment plan, orders, follow-up)

Paper reference:
  "Sentences are weakly tagged as Subjective, Objective, Assessment, or
   Plan (SOAP) via rules and a small manually verified set (≥500 sentences);
   we report section-tagging F1." (Sec. 4)

Implementation status
---------------------
  Rule-based classifier (mirroring the paper's weak-supervision approach).
  Replace the rule-based backend with a fine-tuned ClinicalBERT classifier
  for production use (fine-tuning on the manually verified 500-sentence set).

SOAP-aware filtering (ablation −SOAP, Table 7):
  Weights retrieval results by section type.  Assessment and Plan sections
  typically contain the most diagnostically relevant content.
"""

from __future__ import annotations

import re
from enum import Enum
from typing import Dict, List, Optional, Tuple


# ─────────────────────────────────────────────
# 1. SOAP section taxonomy
# ─────────────────────────────────────────────

class SOAPSection(Enum):
    SUBJECTIVE  = "subjective"   # S — patient-reported history/symptoms
    OBJECTIVE   = "objective"    # O — exam findings, labs, vitals
    ASSESSMENT  = "assessment"   # A — diagnosis / clinical impression
    PLAN        = "plan"         # P — treatment / management
    UNKNOWN     = "unknown"      # no clear section signal


# Retrieval weights per section (used in SOAP-aware re-ranking)
# Assessment and Plan contain active diagnosis/treatment decisions.
# Subjective is clinician-unverified; Objective is factual but data-dense.
SOAP_RETRIEVAL_WEIGHTS: Dict[SOAPSection, float] = {
    SOAPSection.ASSESSMENT:  1.0,   # highest clinical relevance
    SOAPSection.PLAN:        0.9,
    SOAPSection.OBJECTIVE:   0.7,
    SOAPSection.SUBJECTIVE:  0.5,
    SOAPSection.UNKNOWN:     0.6,   # neutral
}


# ─────────────────────────────────────────────
# 2. Cue patterns for rule-based classification
# ─────────────────────────────────────────────

_HEADER_PATTERNS: Dict[SOAPSection, re.Pattern] = {
    SOAPSection.SUBJECTIVE: re.compile(
        r"\b(subjective|chief complaint|cc:|hpi|history of present illness"
        r"|patient reports|patient states|patient complains|patient presents with"
        r"|patient denies|review of systems|ros:)\b",
        re.IGNORECASE,
    ),
    SOAPSection.OBJECTIVE: re.compile(
        r"\b(objective|physical examination|vitals|temperature|bp:|hr:|rr:"
        r"|o2 sat|labs|laboratory|imaging|ekg|ecg|chest x-ray|cxr"
        r"|exam:|on examination|findings|afebrile|alert and oriented)\b",
        re.IGNORECASE,
    ),
    SOAPSection.ASSESSMENT: re.compile(
        r"\b(assessment|impression|diagnosis|diagnoses|clinical impression"
        r"|a:|impression:|working diagnosis|primary diagnosis|secondary diagnosis"
        r"|differential diagnosis|ddx:|problem list)\b",
        re.IGNORECASE,
    ),
    SOAPSection.PLAN: re.compile(
        r"\b(plan|p:|recommendations|orders|management|treatment|therapy"
        r"|follow.up|f/u|discharge|admitted for|will continue|start|stop"
        r"|increase|decrease|monitor|consult|refer|schedule)\b",
        re.IGNORECASE,
    ),
}


# ─────────────────────────────────────────────
# 3. Sentence-level classification
# ─────────────────────────────────────────────

def classify_soap(sentence: str) -> SOAPSection:
    """
    Classify a single sentence into its SOAP section.

    Priority: ASSESSMENT > PLAN > OBJECTIVE > SUBJECTIVE > UNKNOWN
    (Assessment and Plan are more diagnostically actionable.)
    """
    s = sentence.lower().strip()

    priority_order = [
        SOAPSection.ASSESSMENT,
        SOAPSection.PLAN,
        SOAPSection.OBJECTIVE,
        SOAPSection.SUBJECTIVE,
    ]

    for section in priority_order:
        if _HEADER_PATTERNS[section].search(s):
            return section

    return SOAPSection.UNKNOWN


def classify_soap_batch(sentences: List[str]) -> List[SOAPSection]:
    """Classify a list of sentences. Returns one SOAPSection per sentence."""
    return [classify_soap(s) for s in sentences]


# ─────────────────────────────────────────────
# 4. Document-level segmentation
# ─────────────────────────────────────────────

def segment_document(
    sentences: List[str],
) -> Dict[SOAPSection, List[Tuple[int, str]]]:
    """
    Segment a clinical note into SOAP sections.

    Returns a dict mapping SOAPSection → list of (index, sentence) tuples.
    Uses a stateful approach: once a section header is found, subsequent
    sentences inherit that section until a new header is detected.
    """
    segments: Dict[SOAPSection, List[Tuple[int, str]]] = {s: [] for s in SOAPSection}
    current_section = SOAPSection.UNKNOWN

    for i, sentence in enumerate(sentences):
        detected = classify_soap(sentence)
        # A strong header signal upgrades the current section
        has_header = any(
            _HEADER_PATTERNS[s].search(sentence.lower().strip())
            for s in [SOAPSection.SUBJECTIVE, SOAPSection.OBJECTIVE,
                      SOAPSection.ASSESSMENT, SOAPSection.PLAN]
        )
        if has_header:
            current_section = detected
        else:
            # Inherit current section if no header found
            detected = current_section

        segments[detected].append((i, sentence))

    return segments


# ─────────────────────────────────────────────
# 5. SOAP-aware retrieval weighting
# ─────────────────────────────────────────────

def apply_soap_weights(
    results: List[Dict],
    soap_weight_map: Optional[Dict[SOAPSection, float]] = None,
) -> List[Dict]:
    """
    Modulate retrieval scores by SOAP section type (ablation −SOAP variant).

    Each result must have a "text" field. The function classifies the text
    and multiplies the score by the SOAP section weight.

    Parameters
    ----------
    results           : Retrieved result dicts with "text" and "score".
    soap_weight_map   : Custom weight map (default: SOAP_RETRIEVAL_WEIGHTS).

    Returns
    -------
    List of result dicts with "soap_section" and "soap_weighted_score" added,
    sorted by soap_weighted_score descending.
    """
    if soap_weight_map is None:
        soap_weight_map = SOAP_RETRIEVAL_WEIGHTS

    for r in results:
        section = classify_soap(r.get("text", ""))
        weight  = soap_weight_map.get(section, 1.0)
        r["soap_section"]       = section.value
        r["soap_weight"]        = weight
        r["soap_weighted_score"] = r.get("score", 0.0) * weight
        # Update primary score for downstream sorting
        r["score"] = r["soap_weighted_score"]

    return sorted(results, key=lambda x: x["score"], reverse=True)


# ─────────────────────────────────────────────
# 6. Example
# ─────────────────────────────────────────────

if __name__ == "__main__":
    test_sentences = [
        "Patient reports chest pain radiating to left arm for 2 hours.",
        "Vitals: BP 145/90, HR 88, Temp 37.1°C, O2 sat 96%.",
        "ECG shows ST elevation in leads II, III, aVF.",
        "Assessment: Acute inferior STEMI.",
        "Plan: Activate cath lab, start heparin, aspirin 325 mg, nitroglycerin.",
        "Family history of coronary artery disease.",
        "No evidence of prior MI on imaging.",
    ]

    print(f"{'Sentence':<60} {'SOAP Section'}")
    print("-" * 80)
    for sent in test_sentences:
        section = classify_soap(sent)
        print(f"{sent[:59]:<60} {section.value}")

    print("\nDocument segmentation:")
    segments = segment_document(test_sentences)
    for section, items in segments.items():
        if items:
            print(f"\n  [{section.value.upper()}]")
            for idx, s in items:
                print(f"    ({idx}) {s}")
