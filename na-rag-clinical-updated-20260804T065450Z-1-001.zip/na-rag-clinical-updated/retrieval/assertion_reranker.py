"""
Assertion-aware hybrid re-ranking (paper Eq. 1).

Implements the full polarity-aware hybrid retriever scoring function:

    R_MM(q) = argmax_{d_i} [
        λ1 · cos(q, d_i^dense)
      + λ2 · Jaccard(q, d_i^meta)
      + λ3 · NegScore(d_i, q)
    ]

Key fix over previous version
------------------------------
The old implementation multiplied the existing dense score by a weight,
which drives documents with low semantic scores to zero regardless of
assertion alignment.  The corrected approach ADDS a separately computed
NegScore term to the existing hybrid score, as described in the paper.

Design notes
------------
- λ1, λ2, λ3 default values are tuned on validation data. They are
  exposed via utils/config.py for sensitivity analysis (reviewer Q5).
- NegScore is computed via assertion_extraction.compute_neg_score().
- The rerank() function is the main entry point; it accepts pre-retrieved
  results dicts and augments their scores.
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional

from preprocessing.assertion_extraction import (
    Assertion,
    compute_neg_score,
    extract_assertion,
    batch_neg_scores,
)


# ─────────────────────────────────────────────
# λ weights (paper Eq. 1)
# ─────────────────────────────────────────────
# Default values — override via utils/config.py or constructor arg.
# λ1: semantic (dense cosine) weight
# λ2: lexical/metadata (Jaccard) weight
# λ3: assertion-polarity (NegScore) weight
DEFAULT_LAMBDA1 = 0.50   # dense semantic similarity
DEFAULT_LAMBDA2 = 0.20   # lexical / metadata overlap
DEFAULT_LAMBDA3 = 0.30   # assertion/polarity alignment (NegScore)


# ─────────────────────────────────────────────
# Jaccard utility
# ─────────────────────────────────────────────

def jaccard_similarity(text_a: str, text_b: str) -> float:
    """Token-level Jaccard similarity between two strings."""
    if not text_a or not text_b:
        return 0.0
    tokens_a = set(text_a.lower().split())
    tokens_b = set(text_b.lower().split())
    if not tokens_a and not tokens_b:
        return 0.0
    return len(tokens_a & tokens_b) / len(tokens_a | tokens_b)


# ─────────────────────────────────────────────
# Core reranking function
# ─────────────────────────────────────────────

def rerank(
    results: List[Dict[str, Any]],
    query: Optional[str] = None,
    lambda1: float = DEFAULT_LAMBDA1,
    lambda2: float = DEFAULT_LAMBDA2,
    lambda3: float = DEFAULT_LAMBDA3,
) -> List[Dict[str, Any]]:
    """
    Assertion-aware hybrid re-ranking (paper Eq. 1).

    Each result dict must contain:
        "text"      : str  — document text
        "score"     : float — dense cosine score from DenseRetriever
        "assertion" : str  — assertion label (e.g. "affirmed", "negated")

    The function:
    1. Keeps the original dense score as the λ1 component.
    2. Computes a Jaccard similarity with the query for the λ2 component.
    3. Computes NegScore(d_i, q) for the λ3 component.
    4. Combines: hybrid_score = λ1·dense + λ2·jaccard + λ3·NegScore

    Parameters
    ----------
    results  : Retrieved results (each is a dict with text, score, assertion).
    query    : Query text. If None, NegScore defaults to 0 for all results.
    lambda1  : Weight for dense semantic similarity (default 0.5).
    lambda2  : Weight for lexical/metadata Jaccard (default 0.2).
    lambda3  : Weight for assertion polarity alignment (default 0.3).

    Returns
    -------
    List of result dicts with updated "hybrid_score" field, sorted descending.
    """
    if not results:
        return results

    query_assertion = extract_assertion(query) if query else Assertion.AFFIRMED

    for r in results:
        dense_score  = r.get("score", 0.0)
        jac_score    = jaccard_similarity(r.get("text", ""), query or "") if query else 0.0

        # Parse assertion from result dict (handle both str and Assertion enum)
        raw_assertion = r.get("assertion", "affirmed")
        if isinstance(raw_assertion, str):
            try:
                doc_assertion = Assertion(raw_assertion)
            except ValueError:
                doc_assertion = Assertion.UNKNOWN
        else:
            doc_assertion = raw_assertion

        neg_s = compute_neg_score(
            doc_sentence=r.get("text", ""),
            query_sentence=query or "",
            doc_assertion=doc_assertion,
            query_assertion=query_assertion,
        )

        hybrid = (lambda1 * dense_score
                  + lambda2 * jac_score
                  + lambda3 * neg_s)

        r["dense_score"]   = dense_score
        r["jaccard_score"] = jac_score
        r["neg_score"]     = neg_s
        r["hybrid_score"]  = hybrid
        # Overwrite "score" for backward-compat with downstream callers
        r["score"]         = hybrid

    return sorted(results, key=lambda x: x["score"], reverse=True)


# ─────────────────────────────────────────────
# Convenience: ablation variants
# ─────────────────────────────────────────────

def rerank_dense_only(results, query=None):
    """Ablation: λ2=0, λ3=0 (dense-only baseline)."""
    return rerank(results, query, lambda1=1.0, lambda2=0.0, lambda3=0.0)


def rerank_no_nbio(results, query=None):
    """Ablation: −NBIO (remove assertion signal, λ3=0)."""
    return rerank(results, query, lambda1=0.625, lambda2=0.375, lambda3=0.0)


def rerank_lexical_only(results, query=None):
    """Ablation: lexical-only baseline (λ1=0, λ3=0)."""
    return rerank(results, query, lambda1=0.0, lambda2=1.0, lambda3=0.0)


# ─────────────────────────────────────────────
# Backward-compatible wrapper
# ─────────────────────────────────────────────
# Old code called rerank() expecting score-multiplied results.
# The new rerank() sets r["score"] = hybrid_score, so callers that
# only access r["score"] are automatically backward-compatible.


# ─────────────────────────────────────────────
# Example
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import pprint

    sample_results = [
        {"text": "The patient has diabetes.",               "assertion": "affirmed",     "score": 0.85},
        {"text": "No evidence of diabetes mellitus.",       "assertion": "negated",      "score": 0.80},
        {"text": "History of type-2 diabetes.",             "assertion": "historical",   "score": 0.75},
        {"text": "Possible pre-diabetic state.",            "assertion": "hypothetical", "score": 0.70},
        {"text": "Family history of diabetes.",             "assertion": "family",       "score": 0.65},
    ]

    print("=== QUERY: 'Does the patient currently have diabetes?' ===")
    reranked = rerank(sample_results, query="Does the patient currently have diabetes?")
    for r in reranked:
        print(f"  [{r['assertion']:12s}] hybrid={r['score']:.3f} "
              f"(dense={r['dense_score']:.3f}, jac={r['jaccard_score']:.3f}, "
              f"neg={r['neg_score']:.3f})  {r['text']}")

    print("\n=== QUERY: 'ruled out diabetes' (negated query) ===")
    reranked2 = rerank(
        [dict(r) for r in sample_results],
        query="ruled out diabetes"
    )
    for r in reranked2:
        print(f"  [{r['assertion']:12s}] hybrid={r['score']:.3f}  {r['text']}")
