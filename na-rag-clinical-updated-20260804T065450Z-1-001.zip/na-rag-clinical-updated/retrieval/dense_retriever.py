"""
Dense retriever with TF-IDF fallback (paper Eq. 1 hybrid retriever).

Two backends — chosen automatically based on what is installed:
  1. SentenceTransformer (recommended, requires: pip install sentence-transformers)
     Models: all-MiniLM-L6-v2 (fast), Bio_ClinicalBERT (clinical, recommended)
  2. TF-IDF cosine (fallback, no extra install required — uses scikit-learn)

Both backends expose the same interface so experiment scripts are unchanged.
The TF-IDF backend is appropriate for CPU-only runs on i2b2 2012 and
similar corpora. For publication-quality results, switch to a clinical
SentenceTransformer once GPU resources are available.

For the full hybrid pipeline combine with assertion_reranker.rerank().
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional

import numpy as np

# ── Backend selection ─────────────────────────────────────────────────────────
try:
    from sentence_transformers import SentenceTransformer, util as st_util
    _HAS_ST = True
except ImportError:
    _HAS_ST = False

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity as sk_cos
    _HAS_SKLEARN = True
except ImportError:
    _HAS_SKLEARN = False

if not _HAS_ST and not _HAS_SKLEARN:
    raise ImportError(
        "No retrieval backend available. Install at least one of:\n"
        "  pip install scikit-learn          # TF-IDF fallback (CPU, no GPU)\n"
        "  pip install sentence-transformers  # Neural embeddings (recommended)"
    )


# ── TF-IDF backend ─────────────────────────────────────────────────────────────

class _TFIDFRetriever:
    """
    TF-IDF cosine retriever (scikit-learn).

    Runnable without GPU. Suitable for i2b2 2012 and MTSamples experiments.
    Replace with SentenceTransformer backend for publication experiments.
    """

    def __init__(self, max_features: int = 10_000, ngram_range=(1, 2)):
        assert _HAS_SKLEARN, "scikit-learn not installed"
        self._vectorizer = TfidfVectorizer(
            max_features=max_features,
            ngram_range=ngram_range,
            sublinear_tf=True,
            strip_accents="unicode",
            analyzer="word",
        )
        self._corpus_matrix = None
        self._corpus_texts: List[str] = []

    def fit_corpus(self, corpus_texts: List[str]) -> "np.ndarray":
        """Fit vectorizer and encode corpus. Returns sparse matrix as np array."""
        self._corpus_texts = corpus_texts
        self._corpus_matrix = self._vectorizer.fit_transform(corpus_texts)
        return self._corpus_matrix

    def encode(self, texts: List[str]) -> "np.ndarray":
        """Encode texts (query or corpus) using the fitted vectorizer."""
        if self._corpus_matrix is None:
            # First call: fit+transform
            return self.fit_corpus(texts)
        return self._vectorizer.transform(texts)

    def retrieve(
        self,
        query: str,
        corpus_matrix,
        corpus_texts: List[str],
        top_k: int = 10,
        metadata: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Dict[str, Any]]:
        q_vec = self._vectorizer.transform([query])
        scores = sk_cos(q_vec, corpus_matrix)[0]
        effective_k = min(top_k, len(corpus_texts))
        top_idx = np.argsort(scores)[::-1][:effective_k]

        results = []
        for rank, idx in enumerate(top_idx):
            r: Dict[str, Any] = {
                "doc_id": int(idx),
                "text":   corpus_texts[idx],
                "score":  float(scores[idx]),
                "rank":   rank + 1,
                "backend": "tfidf",
            }
            if metadata and int(idx) < len(metadata):
                r["metadata"] = metadata[int(idx)]
            results.append(r)
        return results


# ── SentenceTransformer backend ───────────────────────────────────────────────

class _STRetriever:
    """Neural bi-encoder retriever (sentence-transformers)."""

    def __init__(self, model_name: str, batch_size: int = 64, normalize: bool = True):
        assert _HAS_ST, "sentence-transformers not installed"
        self.model_name = model_name
        self.model = SentenceTransformer(model_name)
        self.batch_size = batch_size
        self.normalize = normalize

    def encode(self, texts: List[str]):
        return self.model.encode(
            texts,
            convert_to_tensor=True,
            batch_size=self.batch_size,
            normalize_embeddings=self.normalize,
            show_progress_bar=False,
        )

    def retrieve(
        self,
        query: str,
        corpus_embeddings,
        corpus_texts: List[str],
        top_k: int = 10,
        metadata: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Dict[str, Any]]:
        q_emb = self.encode([query])
        cos_scores = st_util.cos_sim(q_emb, corpus_embeddings)[0]
        effective_k = min(top_k, len(corpus_texts))
        top_results = cos_scores.topk(k=effective_k)
        top_indices = top_results.indices.tolist()
        top_scores  = top_results.values.tolist()

        results = []
        for rank, (idx, score) in enumerate(zip(top_indices, top_scores)):
            r: Dict[str, Any] = {
                "doc_id": idx,
                "text":   corpus_texts[idx],
                "score":  float(score),
                "rank":   rank + 1,
                "backend": "sentence_transformer",
            }
            if metadata and idx < len(metadata):
                r["metadata"] = metadata[idx]
            results.append(r)
        return results


# ── Public DenseRetriever — auto-selects backend ──────────────────────────────

class DenseRetriever:
    """
    Dense retriever with automatic backend selection.

    Priority: SentenceTransformer (if installed) → TF-IDF (fallback).

    Usage is identical regardless of backend:
        retriever = DenseRetriever()
        corpus_emb = retriever.encode(corpus_texts)   # fit on corpus
        results    = retriever.retrieve(query, corpus_emb, corpus_texts)

    For GPU / publication experiments:
        pip install sentence-transformers
        retriever = DenseRetriever("emilyalsentzer/Bio_ClinicalBERT")

    For CPU / i2b2 / quick runs (current default):
        Uses TF-IDF cosine — no model download needed.
    """

    def __init__(
        self,
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        use_tfidf: Optional[bool] = None,   # None = auto
        max_tfidf_features: int = 10_000,
    ):
        """
        Parameters
        ----------
        model_name          : SentenceTransformer model (ignored if TF-IDF).
        use_tfidf           : True = force TF-IDF; False = force ST; None = auto.
        max_tfidf_features  : TF-IDF vocabulary size.
        """
        if use_tfidf is None:
            use_tfidf = not _HAS_ST

        if use_tfidf:
            self._backend = _TFIDFRetriever(max_features=max_tfidf_features)
            self.backend_name = "tfidf"
            print("[DenseRetriever] Using TF-IDF backend (scikit-learn). "
                  "Install sentence-transformers for neural embeddings.")
        else:
            self._backend = _STRetriever(model_name)
            self.backend_name = f"sentence_transformer({model_name})"
            print(f"[DenseRetriever] Using SentenceTransformer: {model_name}")

    def encode(self, texts: List[str]):
        """Encode corpus texts. Call once; reuse the returned matrix."""
        return self._backend.encode(texts)

    def retrieve(
        self,
        query: str,
        corpus_embeddings,
        corpus_texts: List[str],
        top_k: int = 10,
        metadata: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Dict[str, Any]]:
        """Retrieve top-k results for a query. See class docstring."""
        return self._backend.retrieve(query, corpus_embeddings, corpus_texts, top_k, metadata)


# ── HybridRetriever (BM25 + Dense) ───────────────────────────────────────────

class HybridRetriever:
    """
    Hybrid BM25 + Dense (TF-IDF or SentenceTransformer) retriever.
    Fuses scores via min-max normalisation before assertion reranking.
    """

    def __init__(
        self,
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        lambda_dense: float = 0.70,
        lambda_bm25:  float = 0.30,
    ):
        self.dense = DenseRetriever(model_name)
        self.lambda_dense = lambda_dense
        self.lambda_bm25  = lambda_bm25
        self._bm25 = None

    def _get_bm25(self, corpus_texts: List[str]):
        if self._bm25 is None:
            try:
                from rank_bm25 import BM25Okapi
                self._bm25 = BM25Okapi([t.lower().split() for t in corpus_texts])
            except ImportError:
                print("[HybridRetriever] rank_bm25 not installed; falling back to dense-only.")
        return self._bm25

    def retrieve(
        self,
        query: str,
        corpus_embeddings,
        corpus_texts: List[str],
        top_k: int = 10,
        metadata: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Dict[str, Any]]:
        k_pool = min(top_k * 3, len(corpus_texts))
        dense_res = self.dense.retrieve(query, corpus_embeddings, corpus_texts, k_pool, metadata)
        bm25 = self._get_bm25(corpus_texts)

        if bm25 is not None:
            bm25_scores = bm25.get_scores(query.lower().split())
            dense_vals = [r["score"] for r in dense_res]
            d_min, d_max = min(dense_vals), max(dense_vals)
            d_range = d_max - d_min if d_max != d_min else 1.0
            bm25_vals = [bm25_scores[r["doc_id"]] for r in dense_res]
            b_min, b_max = min(bm25_vals), max(bm25_vals)
            b_range = b_max - b_min if b_max != b_min else 1.0

            for r, bv in zip(dense_res, bm25_vals):
                r["dense_score"] = r["score"]
                r["bm25_score"]  = bv
                r["score"] = (self.lambda_dense * (r["score"] - d_min) / d_range
                              + self.lambda_bm25  * (bv - b_min) / b_range)

        dense_res.sort(key=lambda x: x["score"], reverse=True)
        for rank, r in enumerate(dense_res[:top_k]):
            r["rank"] = rank + 1
        return dense_res[:top_k]


# ── Example ───────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    corpus = [
        "The patient has a history of diabetes.",
        "He is currently experiencing chest pain.",
        "No evidence of infection was found.",
        "Family history of coronary artery disease is noted.",
        "CT scan ruled out appendicitis.",
    ]
    retriever = DenseRetriever()
    corpus_emb = retriever.encode(corpus)
    query = "Does the patient have diabetes?"
    results = retriever.retrieve(query, corpus_emb, corpus, top_k=3)
    print(f"Backend: {retriever.backend_name}")
    for r in results:
        print(f"  [{r['rank']}] score={r['score']:.4f}  {r['text']}")
