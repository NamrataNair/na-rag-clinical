"""
Central configuration for the NA-RAG pipeline (paper Sec. 6).

All λ weights, thresholds, and hyperparameters are defined here so that
sensitivity analyses (reviewer Q5) can be run by changing a single file.

λ weights (Eq. 1 hybrid retriever):
  λ1 : dense cosine similarity weight
  λ2 : lexical/metadata (Jaccard / BM25) weight
  λ3 : assertion polarity (NegScore) weight
  Constraint: λ1 + λ2 + λ3 = 1.0

Setting: Validated on the held-out validation set via grid search over
  λ1 ∈ {0.4, 0.5, 0.6}, λ2 ∈ {0.1, 0.2, 0.3}, λ3 ∈ {0.1, 0.2, 0.3}
  with λ1 + λ2 + λ3 = 1.0. Best: λ1=0.5, λ2=0.2, λ3=0.3.
  Sensitivity analysis in Supplementary Material.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Optional


# ─────────────────────────────────────────────
# Model selection
# ─────────────────────────────────────────────

# Recommended clinical encoder (BioBERT / ClinicalBERT).
# Use all-MiniLM for fast prototyping; swap for clinical model in experiments.
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
CLINICAL_EMBEDDING_MODEL = "emilyalsentzer/Bio_ClinicalBERT"  # recommended

TOP_K = 10   # retrieve top-10 candidates before re-ranking (paper Table 3)
RERANKER_ENABLED = True


# ─────────────────────────────────────────────
# λ weights — Eq. 1 hybrid retriever
# ─────────────────────────────────────────────

LAMBDA1_DENSE     = 0.50   # dense cosine similarity
LAMBDA2_LEXICAL   = 0.20   # BM25 / Jaccard metadata
LAMBDA3_NEG_SCORE = 0.30   # assertion polarity (NegScore)

assert abs(LAMBDA1_DENSE + LAMBDA2_LEXICAL + LAMBDA3_NEG_SCORE - 1.0) < 1e-9, \
    "λ weights must sum to 1.0"

# Hybrid retriever internal fusion (dense vs BM25 before assertion reranking)
LAMBDA_DENSE_IN_HYBRID = 0.70   # within HybridRetriever
LAMBDA_BM25_IN_HYBRID  = 0.30


# ─────────────────────────────────────────────
# ICD filtering (Eq. 3)
# ─────────────────────────────────────────────

ICD_LAMBDA_MIX   = 0.50   # λ in S^hier_ICD = λ·S_ICD + (1−λ)·onto_term
ICD_THRESHOLD    = 0.30   # Minimum S^hier_ICD to keep a result
ICD_FLAG_ONLY    = True   # True: flag but don't remove (safer for experiments)


# ─────────────────────────────────────────────
# SOAP filtering (ablation −SOAP, Table 7)
# ─────────────────────────────────────────────

SOAP_RETRIEVAL_WEIGHTS: Dict[str, float] = {
    "assessment":  1.0,
    "plan":        0.9,
    "objective":   0.7,
    "subjective":  0.5,
    "unknown":     0.6,
}
SOAP_FILTER_ENABLED = True


# ─────────────────────────────────────────────
# N-BIO tagger (Sec. 3.2, Eq. 2)
# ─────────────────────────────────────────────

NBIO_BETA = 0.5    # β in L_neg = L_BIO + β·TripletLoss (Eq. 2)
NBIO_TRIPLET_MARGIN = 1.0   # margin for triplet loss
NBIO_ENCODER = EMBEDDING_MODEL    # encoder backbone for N-BIO module


# ─────────────────────────────────────────────
# Training / fine-tuning
# ─────────────────────────────────────────────

BATCH_SIZE    = 8
LEARNING_RATE = 2e-5
WEIGHT_DECAY  = 0.01
MAX_EPOCHS    = 10
LR_SCHEDULER  = "cosine_annealing"


# ─────────────────────────────────────────────
# Evaluation (Sec. 8)
# ─────────────────────────────────────────────

EVAL_K            = 10     # nDCG@k, Recall@k  (Table 3)
N_BOOTSTRAP       = 1000   # bootstrap resamples for 95% CI
ALPHA             = 0.05   # significance level
MIN_RELEVANCE     = 1.0    # minimum relevance for Recall / MAP


# ─────────────────────────────────────────────
# Data paths (override as needed)
# ─────────────────────────────────────────────

I2B2_TRAIN_DIR = "codes/i2b22012_training/training_2012"
I2B2_TEST_DIR  = "codes/i2b22012_test/test_2012"

# Amrita proprietary dataset (placeholder — update with actual path)
AMRITA_DATA_DIR  = "data/amrita_ehr"
AMRITA_NOTES_DIR = "data/amrita_ehr/notes"


# ─────────────────────────────────────────────
# Ablation variant flags (Table 7)
# ─────────────────────────────────────────────

@dataclass
class AblationConfig:
    """Configuration for a single ablation variant."""
    name: str
    lambda1: float = LAMBDA1_DENSE
    lambda2: float = LAMBDA2_LEXICAL
    lambda3: float = LAMBDA3_NEG_SCORE
    icd_filter: bool = True
    soap_filter: bool = True
    dense_only: bool = False
    lexical_only: bool = False
    description: str = ""


ABLATION_VARIANTS = [
    AblationConfig(
        name="full_model",
        description="Full NA-RAG: Dense + BM25 + NegScore + ICD + SOAP",
    ),
    AblationConfig(
        name="minus_nbio",
        lambda1=0.625, lambda2=0.375, lambda3=0.0,
        icd_filter=True, soap_filter=True,
        description="−NBIO: remove assertion NegScore term (λ3=0)",
    ),
    AblationConfig(
        name="minus_icd_rerank",
        lambda1=LAMBDA1_DENSE, lambda2=LAMBDA2_LEXICAL, lambda3=LAMBDA3_NEG_SCORE,
        icd_filter=False, soap_filter=True,
        description="−ICD rerank: remove ICD-grounded filtering",
    ),
    AblationConfig(
        name="minus_soap",
        lambda1=LAMBDA1_DENSE, lambda2=LAMBDA2_LEXICAL, lambda3=LAMBDA3_NEG_SCORE,
        icd_filter=True, soap_filter=False,
        description="−SOAP filter: remove SOAP section weighting",
    ),
    AblationConfig(
        name="dense_only",
        lambda1=1.0, lambda2=0.0, lambda3=0.0,
        icd_filter=False, soap_filter=False,
        dense_only=True,
        description="Dense-only: cosine similarity baseline",
    ),
    AblationConfig(
        name="lexical_only",
        lambda1=0.0, lambda2=1.0, lambda3=0.0,
        icd_filter=False, soap_filter=False,
        lexical_only=True,
        description="Lexical-only: BM25 baseline",
    ),
]


if __name__ == "__main__":
    print("NA-RAG Configuration")
    print("=" * 50)
    print(f"  Embedding model      : {EMBEDDING_MODEL}")
    print(f"  Top-K                : {TOP_K}")
    print(f"  λ1 (dense)           : {LAMBDA1_DENSE}")
    print(f"  λ2 (lexical)         : {LAMBDA2_LEXICAL}")
    print(f"  λ3 (NegScore)        : {LAMBDA3_NEG_SCORE}")
    print(f"  ICD λ mix            : {ICD_LAMBDA_MIX}")
    print(f"  ICD threshold        : {ICD_THRESHOLD}")
    print(f"  N-BIO β              : {NBIO_BETA}")
    print(f"  Bootstrap resamples  : {N_BOOTSTRAP}")
    print(f"\nAblation variants ({len(ABLATION_VARIANTS)}):")
    for ab in ABLATION_VARIANTS:
        print(f"  [{ab.name}] {ab.description}")
